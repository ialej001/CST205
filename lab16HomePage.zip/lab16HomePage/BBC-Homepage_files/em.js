/* eslint-disable */
(function(t,r,a,c,k,n,o,w){t['em_ns']=k;w=1*new Date();t[k]=t[k]||function(){
  (t[k].q=t[k].q||[]).push(arguments)},t[k].t=w;n=r.createElement(a);n.async=1;
  n.src=c+'/tag'+(t.addEventListener&&'.'||'_.')+'js?'+parseInt(w/1e9, 10);
  o=r.getElementsByTagName(a)[0];o.parentNode.insertBefore(n,o)
})(window,document,'script','https://t.effectivemeasure.net','_em');
