(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"728x90_OMNI_atlas_", frames: [[730,0,178,190],[0,0,728,90]]}
];


// symbols:



(lib.bull = function() {
	this.spriteSheet = ss["728x90_OMNI_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.person = function() {
	this.spriteSheet = ss["728x90_OMNI_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.brandBar_graphic_text_CTA = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgcAAQAAgLAFgKQAIgOAQAAQAcABAAAgIAAAEIgtAAQAAAZASAAQALAAALgFIADAHQgMAHgOgBQgdABAAgkgAASgDQAAgXgRAAQgPAAgCAXIAiAAIAAAAg");
	this.shape.setTransform(68.7,9.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgSAjIAAhDIALAAIABAMIAAAAQAEgHAHgEQAGgDAHAAIAAALQgPAAgJAMIAAAug");
	this.shape_1.setTransform(62.9,9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgXAZQgGgJAAgQQAAgNAHgKQAIgMAPAAQAQAAAHAMQAGAJAAAOQAAAPgGAKQgIALgQgBQgPAAgIgKgAgRAAQAAAMADAHQAFAIAKAAQASAAAAgbQAAgagSAAQgSAAAAAag");
	this.shape_2.setTransform(56.1,9.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAlAjIAAgsQAAgJgCgDQgDgDgHAAQgLAAgJAFIABAJIAAAtIgKAAIAAgvQAAgMgMAAQgJAAgLAGIAAA1IgLAAIAAhDIAKAAIABAFIAAABQANgIALAAQALAAAEAJQALgJANAAQAOAAAEAIQADAFABAKIAAAug");
	this.shape_3.setTransform(46.5,9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AARAjIAAgsQAAgJgCgDQgDgDgHAAQgIAAgMAGIAAA1IgMAAIAAhDIAMAAIAAAFIAAABQAMgIALAAQAMAAAFAHQADAFAAAKIAAAvg");
	this.shape_4.setTransform(32.9,9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgSAjIAAhDIALAAIAAAMIABAAQAEgHAHgEQAHgDAGAAIAAALQgQAAgIAMIAAAug");
	this.shape_5.setTransform(27.1,9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgWAdQgEgFgBgHQAAgKAIgGQAFgDALgBIATgCIAAgEQAAgJgCgDQgEgFgIAAQgJAAgMAFIgCgIQANgFANgBQAWAAAAAYIAAAuIgKAAIAAgIIgBAAQgKAIgMAAQgLAAgFgGgAAAADQgOABAAAMQAAAMANgBQAIAAAJgIIAAgRg");
	this.shape_6.setTransform(20.4,9.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgcAAQAAgLAFgKQAIgOAQAAQAcABAAAgIAAAEIgtAAQAAAZASAAQALAAALgFIADAHQgMAHgNgBQgeABAAgkgAASgDQAAgXgQAAQgQAAgCAXIAiAAIAAAAg");
	this.shape_7.setTransform(13.4,9.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgfAwIAAhfIANAAIAABWIAxAAIAAAJg");
	this.shape_8.setTransform(6.3,7.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.brandBar_graphic_text_CTA, new cjs.Rectangle(0,0,76.6,18), null);


(lib.brandBar_graphic_button_highlight = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// vertical
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhjFeIAAq7IDHAAIAAK7g");
	this.shape.setTransform(10,35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.brandBar_graphic_button_highlight, new cjs.Rectangle(0,0,20,70), null);


(lib.brandBar_graphic_button_basePlate = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0052C2").s().dr(-102.5,-24,205,48);
	this.shape.setTransform(102.5,24);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.brandBar_graphic_button_basePlate, new cjs.Rectangle(0,0,205,48), null);


(lib.person_mc = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.person();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.person_mc, new cjs.Rectangle(0,0,728,90), null);


(lib.hit_area = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.logo_big = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ADxITQAZggAthXQgXAKgdgEQgggFgKgTQgJgQgJAGIgPARQgIALgaAtQgdAzgIAXIiOAAQAhglAZg4QAZg5gEggIgpAHQABgSgRgIQgUgIgaAVQADAUgCAkQgCAigFAYQg9ABg4gbQg5gbgNgoQgCgFgKAFQgNAHgFAAQgLAAgLgFQgIgEgFgFQgBAOgKAmQgKApgCALQgHA4ADAOIh3AAQASg5ACg7QAChCgUgnQgSgkgCgtQgDgtAPgSQgegogFguQgGhCAohcQAvhtAXhgQgdASggADQgFgRAGgZQAGgcAQgKQgRgUgHgUQgHgTAAgYQAAgnAlghQAjgeAmAAQAnAAARARQgPAFgKAOQgJAMAAALQAAALAGAKQAGAKAKAAQAJAAAFgDIAJgHIB5AAQAJAMAQAAQAPAAAKgLQAJgKAAgNQAAgNgHgMQgJgPgQgFQAUgQAaAAQAiAAAgAgQAiAkAAAzQAAAagFAPQgFAVgQAPQAMAMAIAUQAIASADARIgeACIgeAAQAIAMAVAqQAUAqAHARQAyCBBSAlQBFAgA5AKQBDALA/gRQAagGASgZQARgXAAgYQAAgdgpgjQgmgfgwgQQhwgag4gaQhlguAChZQABgxAwgjQAxglBFABQA0AADPgFQgJAsglArQgrAygvAAQgqAAgWgMQgUgPgNgGQgxgagfAAQgZAAgUAOQgYASAAAgQAAAbAUAVQAXAaAvAPQAXAHA/ASQA8ASAnARQB1A0AABTQAAA2gvAkQgvAkhNACQAlA1AWA1QANAeAbAgQAjAoAgAHQggAugYA8QgbBBAAAqgACYBoQgWAUAAAfQAABCA9AlQAcARAvAVIA5AXQAkAOAHAYQAGAXgUAoQgQAhgXAsIA4AAQAIgfAVgyQAUgzAQgaQgfgTgXgrQghg8gMgYQgQgigbgdQgqgtgpAAQgjAAgWATgAmwDiQgDAEAAAHQAAAVAXBHQANArABAuQAAAqgKAlIAdAAQAEgPAKg7QAJg/AAgYQAAgjgggqQgegmgEAAQgGAAgEAFgABfFYQAAAogSAyQgNAjgPAbIAkAAQARgjAdgyQAjg8AIgGIACgQQg3ADgaAMgAiWDxQgRAMgTAaQgcAnAAATQAAAOAKAOQANASAWAJQASAIAVAGQAVAFANgBQADgLABgQQACgSgCgKQgTAFgfgCQgigCgGgLQAKgMAWgFIAdgIQAOgEATgOQAYgTAAgPQAAgQgMgMQgMgMgVAAQgWAAgTANgADpFpQAIARAQACQARACAOgHQAMgEAFgJQgIgIgdgKQgZgKgRgEQABATAGAMgAnAAXQgLAKgBAVQgBAYAOAcQAaA4B1CXQAHAJAMABQAMAAAJgHQAognAPgeQAXguAgghQAcgcAvgdQAigVAUgiQAZgqAAg2QAAg5gthUQgWgpgrg9QgMAFgNAQQgPATAAARQAAAGAEAHQADAGAAAIQAAAKgHAFQgGAEgHAAQgDAAgFgCIgJgEQgHgEgVgCQgZgDgNAEQgNADgJAEQgEACgGgGQgIgHAAgJQAAgIAHgFQAHgGAGABQAGgBASAHQAWAHAVgJQARgHgGgPQgFgPAAgVQAAgRAHgTQAIgVANgMIA8AAQAeACAVgZQARgWAAgYQAAgSgNgVQgLgTgNgIQAJAYgFAVQgEARgNAMQgRAQgWAAQgHAAgMgDQgOgGgGgGIh7AAQgDAIgIAGQgKAGgMAAQgNAAgQgNQgPgLgFgLQgFgLAAgNQABgQAHgNQgUACgOAOQgPAPAAAYQAAAdAYAYQAXAXAbAEQgGA0gfBbQgYBHgWAyQgFAOABALQABASAQAHQAYALAdAkQAgArAFAoIggAAQgCgMgKgSQgIgQgIgLQgTgZgTgGQgGgCgFAAQgKAAgHAHgAA3EtIBTgXQgSgSgPgkQgQgmAAgdQAAgfAOgdQAPgeAYgIQgUgHgkgaQgmgagMgTQACAUgJAeQgIAfgPAWQgMATgqAfQgrAggMAQQAlADAXAhQAXAegEAkIBTgSQgGALACAYgAibk4QgOANACAYQAWgCANgNQANgOgBgXQgXACgMANgAEHmIQgEAKAMAIQAKAGAVAHQAYAHAUAAQAUAAAZgSQATgPAMgRIiBAAQgaAAgEAMgAixiVQgSgKgaABQgagBgTAKQgFACgDgEQgCgGAHgIQASgQAegBQAeABASAQQAHAIgCAGQgCACgDAAIgEAAgAkzkmQgLgOABgUQAWAAAMAOQALANgBAVQgWgBgMgNg");
	this.shape.setTransform(77.1,40.1,0.36,0.36);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAPAhIAAgnQAAgJgBgCQgDgHgIAAQgHABgGAGQgFAGAAALIAAAhIgJAAIAAhAIAJAAIAAANIAAAAQAGgOANAAQAMAAAGAKQADAEAAARIAAAig");
	this.shape_1.setTransform(106.1,88.8,0.36,0.36);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgVAXQgHgJAAgOQAAgOAIgIQAIgKANAAQANAAAIAKQAHAKAAAMQAAAOgIAKQgIAKgNgBQgOAAgHgKgAgOgPQgDAGAAAJQAAALAEAGQAFAIAIAAQAJAAAGgJQADgGAAgKQAAgJgEgIQgFgIgJABQgJAAgFAJg");
	this.shape_2.setTransform(103.6,88.8,0.36,0.36);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEArIAAg/IAJAAIAAA/gAgEgfIAAgMIAJAAIAAAMg");
	this.shape_3.setTransform(101.9,88.4,0.36,0.36);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgHAVIAAgkIgLAAIAAgIIALAAIAAgQIAJgBIAAARIAOAAIAAAIIgOAAIAAAlQAAALAKAAIAHAAIAAAIIgJAAQgRAAAAgUg");
	this.shape_4.setTransform(100.5,88.5,0.36,0.36);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgUAdQgHgGAAgJQAAgMAMgFQAIgDAPAAIAJAAIAAgEQgBgPgQAAQgOAAgCAMIgKgCQADgRAYAAQAOgBAGAHQAFAFAAAQIAAAXQABAKABAEIgKAAIgBgMQgHANgPAAQgJAAgGgEgAgRAOQABAMAOAAQAHAAAGgGQAFgHABgJIAAgEIgJAAQgZAAAAAOg");
	this.shape_5.setTransform(98.5,88.8,0.36,0.36);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgPAhIAAhAIAJAAIAAAQQAGgRAMAAIAEAAIAAAJIgCAAQgLABgFAJQgDAGAAAIIAAAgg");
	this.shape_6.setTransform(96.7,88.8,0.36,0.36);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgVAXQgHgJAAgOQAAgOAHgIQAJgKANAAQANAAAIAKQAHAKAAAMQAAAOgHAKQgJAKgNgBQgOAAgHgKgAgOgPQgDAHAAAIQAAAKAEAHQAEAIAJAAQAKAAAEgJQAEgGAAgKQAAgJgEgIQgFgIgJABQgKAAgEAJg");
	this.shape_7.setTransform(94.7,88.8,0.36,0.36);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgaArIAAhUIAJAAIAAANIAAAAQAFgOAOAAQAMAAAHALQAGAJAAANQAAALgFAKQgHAMgNAAQgLAAgHgMIAAAfgAgLgdQgEAFgBAGIAAAQQAAAGAFAGQAFAFAGAAQAJAAAEgHQADgGAAgLQAAgZgQAAQgGAAgFAFg");
	this.shape_8.setTransform(92.3,89.1,0.36,0.36);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgPAhIAAhAIAJAAIAAAQQAGgRAMAAIAEAAIAAAJIgCAAQgLABgFAJQgDAGAAAIIAAAgg");
	this.shape_9.setTransform(90.3,88.8,0.36,0.36);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgVAXQgHgJAAgOQAAgOAIgIQAIgKANAAQANAAAIAKQAHAJAAANQAAAOgIAKQgIAKgNgBQgNAAgIgKgAgOgPQgDAHAAAIQAAAKAEAHQAFAIAIAAQAKAAAFgJQADgGAAgKQAAgKgEgHQgFgIgJABQgJAAgFAJg");
	this.shape_10.setTransform(88.2,88.8,0.36,0.36);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgZAeQgHgNgBgRQAAgTAJgLQAKgOAQAAQAZABAHAbIgKACQgGgVgQAAQgLABgHAMQgEAJAAANQAAANADAJQAHAOALgBQASABAFgWIAKACQgIAcgZAAQgQAAgKgOg");
	this.shape_11.setTransform(85.6,88.4,0.36,0.36);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgUAdQgHgGAAgJQAAgMAMgFQAIgDAQAAIAIAAIAAgEQAAgPgRAAQgOAAgCAMIgJgCQACgRAYAAQAPgBAFAHQAFAFABAQIAAAXQgBAKACAEIgKAAIgBgMQgGANgQAAQgJAAgGgEgAgRAOQABAMAOAAQAHAAAGgGQAGgHAAgJIAAgEIgIAAQgaAAAAAOg");
	this.shape_12.setTransform(81.7,88.8,0.36,0.36);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgTAXQgGgJAAgOQAAgNAGgJQAIgKANAAQAUgBAEAWIgJACQgCgPgNAAQgQAAAAAYQAAAZAPAAQANAAADgQIAJACQgEAXgVgBQgMAAgIgKg");
	this.shape_13.setTransform(79.3,88.8,0.36,0.36);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgEArIAAg/IAJAAIAAA/gAgEgfIAAgMIAJAAIAAAMg");
	this.shape_14.setTransform(77.8,88.4,0.36,0.36);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgPAhIAAhAIAJAAIAAAQQAGgRAMAAIAEAAIAAAJIgCAAQgLABgFAJQgDAGAAAIIAAAgg");
	this.shape_15.setTransform(76.5,88.8,0.36,0.36);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgVAYQgHgKAAgOQAAgNAHgJQAJgKANAAQAOAAAHAKQAHAKAAANIguAAQAAAKADAEQAFAKAKAAQAMAAAFgMIAKABQgHATgVAAQgNABgIgKgAgLgTQgFAFAAAJIAiAAQAAgJgFgFQgEgGgIAAQgHAAgFAGg");
	this.shape_16.setTransform(74.4,88.8,0.36,0.36);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAiAhIAAgmQgBgIgCgEQgDgHgHAAQgIAAgEAIQgEAEAAALIAAAiIgJAAIAAgoQAAgHgCgDQgDgHgHAAQgHAAgFAHQgEAEAAAKIAAAkIgKAAIAAhAIAJAAIAAANQAGgOANAAQAOAAADAQQAHgQAOAAQALAAAFAJQADAFAAANIAAAmg");
	this.shape_17.setTransform(71.4,88.8,0.36,0.36);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAXArIgJgZIgfAAIgHAZIgJAAIAchWIALAAIAcBWgAgOAKIAaAAIgMgog");
	this.shape_18.setTransform(68.3,88.4,0.36,0.36);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgIAsIAAg3IgLAAIAAgIIALAAQgBgaAUACIAJABIAAAIIgJgBQgHAAgCAFQgBADAAAIIAPAAIAAAIIgPAAIAAA3g");
	this.shape_19.setTransform(65,88.4,0.36,0.36);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgVAXQgHgJAAgOQAAgOAIgIQAIgKANAAQANAAAIAKQAHAKAAAMQAAAOgIAKQgIAKgNgBQgOAAgHgKgAgOgPQgDAGAAAJQAAALAEAGQAFAIAIAAQAJAAAGgJQADgGAAgKQAAgJgEgIQgFgIgJABQgKAAgEAJg");
	this.shape_20.setTransform(63.1,88.8,0.36,0.36);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAQArIgSgkIgOARIAAATIgKAAIAAhWIAKAAIAAA3IAdgfIALAAIgUAVIAWApg");
	this.shape_21.setTransform(59.6,88.4,0.36,0.36);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAPAhIAAgnQAAgJgBgCQgDgHgIAAQgHABgGAGQgFAGAAALIAAAhIgJAAIAAhAIAJAAIAAANIAAAAQAGgOANAAQAMAAAGAKQADAEAAARIAAAig");
	this.shape_22.setTransform(57.1,88.8,0.36,0.36);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgUAdQgHgGAAgJQAAgMAMgFQAIgDAQAAIAIAAIAAgEQAAgPgQAAQgPAAgCAMIgJgCQACgRAYAAQAPgBAFAHQAFAFAAAQIAAAXQAAAIACAGIgKAAIgBgMQgHANgPAAQgJAAgGgEgAgQAOQAAAMAOAAQAIAAAFgGQAGgHAAgJIAAgEIgIAAQgZAAAAAOg");
	this.shape_23.setTransform(54.6,88.8,0.36,0.36);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgeArIAAhWIAfAAQAMAAAGAFQAJAFAAAMQAAAQgOADIAAABQAHABAFAFQAFAGAAAIQAAAMgIAGQgHAHgPgBgAgTAiIAUAAQAKAAAEgDQAGgFAAgHQAAgJgHgEQgEgEgKAAIgTAAgAgTgFIARAAQAKAAAFgEQAFgDAAgIQAAgHgGgEQgFgDgHAAIgTAAg");
	this.shape_24.setTransform(52.2,88.4,0.36,0.36);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgaArIAAhUIAaAAIAAAMQAJgNASAAIAAAbQgFgCgGAAQgKAAgFAGIAAA2g");
	this.shape_25.setTransform(59,79.7,0.36,0.36);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgaArIAAhUIAaAAIAAAMIABAAQAIgNASAAIAAAbQgGgCgFAAQgJAAgGAGIAAA2g");
	this.shape_26.setTransform(56.8,79.7,0.36,0.36);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgaAfQgJgMAAgRQAAgSAJgNQALgPARAAQATAAAJAOQAGAJAAALIgXAAIgCgLQgCgFgFAAQgGAAgCAHQgCAHAAANQAAAZAKAAQAKAAAAgQIAVADQgDAggfgBQgQAAgLgNg");
	this.shape_27.setTransform(76.4,79.7,0.36,0.36);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgNAMIAAgXIAaAAIAAAXg");
	this.shape_28.setTransform(60.9,77.4,0.36,0.36);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgNAqIAAhTIAaAAIAABTg");
	this.shape_29.setTransform(60.9,79.7,0.36,0.36);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgaAfQgKgMAAgTQAAgSAKgMQAKgNARAAQATAAAJAOQAIAMAAARIAAAGIgtAAQAAAUALAAQAMAAACgLIATAGQgJAXgZAAQgSAAgKgNgAgGgVQgDAFABAHIATAAQABgRgLAAQgEAAgDAFg");
	this.shape_30.setTransform(54.1,79.7,0.36,0.36);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AAIArIAAg5QAAgIgGAAQgFAAgDAGIAAA7IgcAAIAAhUIAbAAIAAAJIABAAQAIgKAOAAQATAAAAATIAABCg");
	this.shape_31.setTransform(73.5,79.7,0.36,0.36);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AAHA8IAAg8QAAgGgGAAQgDAAgDADIgCACIAAA9IgbAAIAAh3IAbAAIAAAvQAJgOAPAAQAIAAAFAGQAFAFAAAJIAABCg");
	this.shape_32.setTransform(79.4,79.1,0.36,0.36);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgiA3IAAgUIAHABQAQgBAAgJIgBgIIgXhIIAcAAIAJAxIABAAIAMgxIAVAAIgdBWQgHAXgaAAg");
	this.shape_33.setTransform(70.6,80.2,0.36,0.36);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgjA8IAAh3IAeAAIAABiIApAAIAAAVg");
	this.shape_34.setTransform(67.9,79.1,0.36,0.36);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgNA8IAAh3IAbAAIAAB3g");
	this.shape_35.setTransform(63.9,79.1,0.36,0.36);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgNA8IAAh3IAbAAIAAB3g");
	this.shape_36.setTransform(62.4,79.1,0.36,0.36);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AAaA8IAAhYIAAAAIgVBYIgSAAIgThbIAAAAIAABbIgYAAIAAh3IArAAIANBCIAAAAIAPhCIAqAAIAAB3g");
	this.shape_37.setTransform(50.4,79.1,0.36,0.36);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AA2B4QAHgIAJgSQgFACgHgBQgHgBgCgFQgDgFgEAHIgIANQgHALgBAFIggAAQAHgIAFgMQAGgNgBgIIgJACQAAgEgDgCQgEgCgGAFQABAKgDAQQgOAAgMgGQgNgGgDgJQAAgBgBAAQAAAAAAAAQAAAAgBAAQAAAAgBAAIgEACQgEAAgEgDQAAAGgFARIgBAQIgbAAQAKgggKgSQgEgIAAgKQgBgKAEgFQgQgUAPgiQAKgXAGgXQgHADgHABQgBgEACgFQABgGAEgDQgHgIAAgLQAAgJAIgHQAIgHAJAAQAIAAAEAEQgHADAAAHQAAAHAFAAIAFgDIAbAAQADADADAAQADAAADgCQACgDAAgDQAAgIgIgCQAEgDAHAAQAIAAAHAHQAHAIAAAMQAAALgFAGQAFAGABAJIgNABIAMAZQAMAeASAHQAgAPAagHQAGgBAEgGQAEgEAAgFQAAgHgJgIQgJgHgLgEQgagGgMgFQgXgLAAgUQABgLALgIQALgJAPAAIA7AAQgCAJgIAKQgKAMgLAAQgKAAgEgDIgIgFQgLgGgHAAQgGAAgEADQgGAEAAAIQAAANAVAHIAqAOQAaALAAATQAAAMgKAIQgLAIgSAAQAKAPAEAJQADAHAGAHQAIAJAHACQgTAcAAAUgAAiAYQgFAEAAAHQAAAPAOAJQANAIARAFQAIAEACAFQABAFgEAJIgJASIANAAQADgRALgTQgHgEgFgKIgKgTQgEgIgGgHQgJgKgKAAQgIAAgFAFgAhiA2QAAAEAFARQAGATgFATIAHAAIADgRIACgUQAAgGgHgLQgHgJgBAAQgBAAgBAAQAAABgBAAQAAABAAAAQAAABAAABgAAVBOQAAAJgEALQgDAJgDAFIAIAAQAPgdAFgFIABgDQgLAAgIADgAgqA/QgGAJAAAEQAAAIAKAFQAKAFAHgBQACgGgBgGQgFABgHgBQgHAAgCgDQACgCAFgCIAHgBIAIgFQAFgEAAgDQAAgJgKAAQgJAAgJALgAA6BWQAIABADgFQgEgEgOgDQAAALAHAAgAhlAFQgGAGAGANQAGANAbAiQAAABABAAQAAABABAAQAAAAABAAQAAAAABAAQABAAAAAAQABAAABAAQAAAAABAAQAAgBABAAQAJgKADgGQAJgSAVgNQARgLAAgWQAAgUgYgkQgDACgDADQgDAFAAAEIABAGQAAAEgEAAIgEgBQgCgCgEAAQgFgBgEABIgFACQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAABgBQAAAAAAAAIADgCIAGACQAEACAFgDQAEgBgBgEQgBgCAAgGQAAgKAGgFIAOAAQAHAAAEgGQAEgFAAgFQAAgEgDgFQgCgFgDgBQACAFgBAFQgDAKgKAAQgGAAgDgDIgcAAQgCAEgFAAQgHAAgEgHQgDgGADgHQgLACAAALQAAAHAGAFQAFAFAGABQgDAZgQAjQgDAIAGADQAGADAGAHQAIAKABAJIgIAAQAAgGgGgHQgGgIgFAAQAAAAgBABQgBAAAAAAQgBAAAAAAQgBABAAAAgAAMBEIATgFQgEgEgDgIQgEgJAAgGQAAgIADgGQAEgHAFgCQgFgBgIgGQgIgGgDgDQACAKgJAMQgCAEgJAHIgNALQAJABAFAHQAFAHgBAIIASgEIgBAIgAglg+QALgBgBgKQgLABABAKgAA8hYQgBAAAAABQAAABABAAQAAABAAAAQABAAAAABQAHAFAKAAQAJAAAJgMIgeAAQgFAAgBADgAgnghQgGgCgEAAQgFAAgGACQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAAAABgBQADgDAIAAQAHAAADADIACADIgBABIgBAAgAhHhKQAKABAAAKQgLgBABgKg");
	this.shape_38.setTransform(42.1,76.9,0.36,0.36);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgGAHQgDgDAAgEQAAgDADgDQADgDADAAQAEAAADADQADADAAADQAAAEgDADQgDADgEAAQgDAAgDgDgAgHAAQAAAIAHAAQAIAAAAgIQAAgHgIAAQgHAAAAAHgAADAFIgCgEIgCAAIAAAEIgCAAIAAgJIAEAAQAEAAAAADIgCACIACAEgAgBAAIACAAQAAAAABAAQAAAAAAAAQAAAAABgBQAAAAAAAAQAAgBAAAAQgBAAAAAAQAAgBAAAAQgBAAAAAAIgCAAg");
	this.shape_39.setTransform(108.1,75.1,0.36,0.36);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AAWBMQgKgLgDgYQgBgMAAgdQAAgcABgMQADgXAKgMQAPgTAZAAQAWAAAPAOQAPAQAAAaIgkAAQgCgWgOAAQgJAAgDAHQgFAKAAArQAAAtAFAJQADAHAJAAQAQAAAAgVIAAgTIgQAAIAAgdIA0AAIAAAuQAAAbgOAPQgOAPgYAAQgZAAgPgTgACFBdIAAi4IBVAAIAAAhIgwAAIAAAqIApAAIAAAgIgpAAIAAArIAwAAIAAAigAhxBdIAAi4IA0AAQAZAAAQARQAJAMADAXQABALAAAcQAAAdgBALQgDAYgJALQgQASgZAAgAhMA7IAOAAQAKAAAEgIQAEgIAAgrQAAgqgEgIQgEgIgKAAIgOAAgAjZBdIAAi4IBWAAIAAAhIgxAAIAAAqIAqAAIAAAgIgqAAIAAArIAxAAIAAAig");
	this.shape_40.setTransform(99.6,78.1,0.36,0.36);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AAtBkQAGgIAHgOQgEABgFAAQgGgBgCgEQAAAAgBgBQAAAAgBgBQAAAAgBAAQAAAAgBAAIgCAEIgHAKIgHAOIgaAAQAFgHAFgLQAFgKgBgHIgHACQAAgDgDgCQgEgCgEAEQABAMgDAKQgLAAgLgFQgKgFgDgHQAAgBAAAAQAAAAAAAAQgBAAAAAAQAAAAgBABIgDABQgFAAgCgDIgEAUIgBANIgWAAQAIgbgIgPQgEgGAAgJQAAgIADgEQgOgRANgcQAJgTAEgUQgGAEgFABQgBgEABgEQABgGADgCQgFgGAAgJQAAgIAHgFQAGgHAHAAQAIAAADADQgHAEAAAEQAAAHAFgBIAEgBIAXAAQACACACAAQAHAAAAgHQAAgGgGgCQAEgDAEAAQAHAAAGAGQAFAHAAAKQAAAJgEAFQAEAFABAIIgKAAIAKAVQAIAYAQAGQAbANAWgGQAFgBADgEQADgEAAgEQAAgGgHgHQgIgGgJgDQgVgFgLgFQgTgIABgRQAAgJAJgGQAJgIANABIAxgBQgCAIgHAIQgIAKgIAAQgIgBgEgCIgHgDQgIgFgHgBQgEAAgEADQgFADAAAHQAAAKARAHIAjALQAWAKAAAPQAAAKgJAGQgJAHgOAAQAIALADAKQACAGAFAFQAHAIAGABQgQAYAAAQgAAcATQgEAEAAAGQAAAMAMAIQAKAGAPAFQAMAFgHAOIgHAPIAKAAQAFgRAIgNQgGgEgFgIIgIgQQgDgGgFgFQgIgJgIAAQgGAAgFADgAhRAsQAAAFAEANQAFAQgEAQIAFAAIADgOIACgRQAAgHgGgHIgHgHQAAAAgBAAQAAAAAAAAQgBABAAAAQAAABAAAAgAASBAQAAAPgJAOIAHAAQANgaAEgCIAAgDQgJAAgGACgAgiA0QgGAIAAADQAAAHAJAEQAHADAHAAQABgGgBgEQgDABgGAAQgHgBgBgCQACgCAKgCQALgFAAgFQAAgIgJAAQgHAAgHAJgAAwBHQAHACACgFQgCgCgNgEQACAJAEAAgAhUAFQgFADAFAMQAFALAWAcQAEAEAEgDQAGgGAEgIQAIgPARgKQAOgJAAgTQAAgKgIgQIgMgUQgCABgDAEQgDADAAADIACAFQAAABAAABQAAABgBAAQAAABgBAAQgBAAgBAAIgDgCIgFgBIgIABIgEABIgCgBIgBgCQAAgEAEAAIAEABQADABAFgBQABAAABgBQAAAAABgBQAAAAAAgBQAAgBgBgBIgBgHQAAgHAGgFIALAAQAGAAADgFQAEgEAAgEQAAgDgDgEQgCgFgCgBQABAEAAAFQgDAIgIABQgFAAgCgDIgXAAQgCADgFAAQgFAAgEgGQgCgEADgHQgKABAAAKQAAAFAFAFQAEAEAFABQgCAUgNAeQgDAHAFACQAFACAFAHQAGAHABAIIgGAAIgFgLQgFgGgEAAQAAAAgBAAQAAAAgBAAQAAAAgBABQAAAAgBABgAAKA4IAQgEQgDgDgDgHQgDgHAAgGQAAgPAKgDQgEgBgHgFQgHgFgCgCQABAJgHAJQgCADgHAGIgLAKQAHAAAFAGQAEAGgBAGIAPgDIgBAGgAgfgzQAJgBAAgJQgKAAABAKgAAxhJQAAAAAAABQAAAAABABQAAAAAAABQAAAAABAAQAGAEAIAAQAHAAAHgJIgYAAQgFAAgBACgAghgbQgDgCgFAAQgFAAgDACQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAAAIABgCQADgEAGAAQAGAAADAEIABACIgBABIgBAAgAg7g9QAIAAAAAJQgIAAAAgJg");
	this.shape_41.setTransform(112.8,77.9,0.36,0.36);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgSAcIAAg2IARAAIAAAoIAUAAIAAAOg");
	this.shape_42.setTransform(101,73.2,0.36,0.36);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgSAcIAAg2IARAAIAAAoIAUAAIAAAOg");
	this.shape_43.setTransform(99.3,73.2,0.36,0.36);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgIAcIAAg2IAQAAIAAA2g");
	this.shape_44.setTransform(97.8,73.2,0.36,0.36);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AAGAcIgHgWIgFAAIAAAWIgSAAIAAg2IAbAAQAKAAAFADQAGAEAAAJQAAAKgJADIAKAZgAgGgFIAGAAQAHAAAAgFQAAgDgDgBIgKgBg");
	this.shape_45.setTransform(96.3,73.2,0.36,0.36);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AAGAcIgHgWIgGAAIAAAWIgRAAIAAg2IAbAAQAJAAAGADQAGAEAAAJQAAAKgJADIAKAZgAgHgFIAHAAQAHAAAAgFQAAgDgDgBIgLgBg");
	this.shape_46.setTransform(94.1,73.2,0.36,0.36);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgUAcIAAg2IApAAIAAAMIgYAAIAAAIIATAAIAAALIgTAAIAAAJIAYAAIAAAOg");
	this.shape_47.setTransform(92.1,73.2,0.36,0.36);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AAOAcIAAgnIgKAnIgKAAIgKgnIAAAnIgNAAIAAg2IAWAAIAHAcIAIgcIAWAAIAAA2g");
	this.shape_48.setTransform(89.9,73.2,0.36,0.36);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_big, new cjs.Rectangle(38,21,78.2,69.7), null);


(lib.copy7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgUAMQAAgaAUAAQAHAAAGAEIAAgZIAIAAIAABGIgHAAIgBgFQgHAGgHAAQgTAAAAgYgAgLAMQAAASALAAIAGgCQAFgBACgDIAAgcQgGgDgHAAQgLAAAAATg");
	this.shape.setTransform(213.6,6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgTAAQAAgIADgHQAFgJALgBQAVAAgBAYIAAADIgfAAQgBARANAAQAIAAAIgDIACAFQgIAFgKAAQgVAAABgagAANgDQAAgPgMAAQgLAAgBAPIAYAAIAAAAg");
	this.shape_1.setTransform(208.5,7.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgIATIAAgfIgHAAIAAgEIAHgCIADgMIAFAAIAAAMIAOAAIAAAGIgOAAIAAAdQAAAHAGAAIAJgCIABAGQgGADgGAAQgMAAAAgMg");
	this.shape_2.setTransform(204.2,6.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgQAVQgDgEAAgFQAAgHAFgEQAFgDAHAAIAOgBIAAgDQAAgGgCgDQgDgDgGAAQgGAAgIADIgCgFQAJgEAJAAQARAAAAAQIAAAhIgIAAIAAgGQgIAGgIAAQgIAAgEgEgAAAACQgKABAAAIQAAAJAJAAQAGAAAHgGIAAgNg");
	this.shape_3.setTransform(199.9,7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgNAZIAAgwIAIAAIAAAJIABAAQADgFAEgCQAFgDAFAAIAAAIQgLAAgGAIIAAAhg");
	this.shape_4.setTransform(196.2,7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgQASQgFgGAAgLQABgLAEgGQAGgJALAAQALAAAFAJQAFAGgBAKQABALgFAHQgGAHgLABQgLAAgFgIgAgMABQAAAIACAEQADAGAIAAQAMAAAAgSQAAgTgMAAQgNAAAAATg");
	this.shape_5.setTransform(191.6,7.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgTAkIAAhGIAHAAIABAFIAAAAQAHgFAGgBQATAAgBAZQAAAKgDAIQgGAHgKABQgIAAgEgEIAAAYgAgGgaIgFADIAAAdIAEACIAHABQAMABAAgUQAAgRgMAAIgGABg");
	this.shape_6.setTransform(186.4,8.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgMAZIAAgwIAHAAIAAAJIABAAQADgFAEgCQAFgDAGAAIAAAIQgMAAgGAIIAAAhg");
	this.shape_7.setTransform(182.3,7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgQASQgFgGABgLQAAgLAEgGQAGgJALAAQALAAAFAJQAFAGgBAKQABALgFAHQgGAHgLABQgLAAgFgIgAgMABQAAAIACAEQADAGAIAAQAMAAAAgSQAAgTgMAAQgNAAAAATg");
	this.shape_8.setTransform(177.7,7.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgSABQAAgKAEgGQAGgJALgBQAJAAAGAEIgDAGQgGgDgGAAQgGAAgDAFQgEAGAAAIQAAASANAAQAHAAAHgEIACAFQgHAGgKAAQgUAAAAgZg");
	this.shape_9.setTransform(172.9,7.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAMAZIAAgfQAAgGgCgCQgCgDgFAAQgFAAgJAFIAAAlIgIAAIAAgwIAIAAIAAAEQAJgFAHAAQAJAAAEAFQACADAAAIIAAAhg");
	this.shape_10.setTransform(168,7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgDAiIAAhDIAHAAIAABDg");
	this.shape_11.setTransform(164.1,6.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgFAJQAEgEAAgFQgDgBAAgEQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQABAAAAAAQAAAAAAAAQABAAABAAQAAAAABAAQAAABABAAQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQAAAAAAABQAAAEgCAEQgDAFgEACg");
	this.shape_12.setTransform(159,9.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAMAkIAAghQAAgEgCgDQgBgCgGAAQgFgBgJAFIAAAmIgIAAIAAhGIAIAAIAAAPIAAALIABAAQAKgFAGgBQAJAAADAGQACADAAAHIAAAig");
	this.shape_13.setTransform(155.5,6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgIATIAAgfIgHAAIAAgEIAHgCIADgMIAFAAIAAAMIAOAAIAAAGIgOAAIAAAdQAAAHAGAAIAJgCIABAGQgGADgGAAQgMAAAAgMg");
	this.shape_14.setTransform(151.2,6.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgDAiIAAgxIAHAAIAAAxgAgDgYQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAABAAQAAgBAAAAQAAAAABABQABAAAAAAQABAAAAAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQAAAAgBgBg");
	this.shape_15.setTransform(148.1,6.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAbAZIAAggQAAgFgDgCQgCgDgEAAQgIAAgHAEIABAGIAAAgIgHAAIAAghQAAgJgIAAQgHAAgHAFIAAAlIgIAAIAAgwIAHAAIABAEIAAABQAIgGAIAAQAJAAACAGQAIgGAKAAQAJAAADAFQADAEAAAHIAAAhg");
	this.shape_16.setTransform(142.9,7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgXAeIADgGQAKAEAJAAQAIAAAEgCQAEgEAAgHQAAgFgEgDQgDgCgIgCQgKgDgFgCQgGgEAAgJQAAgJAGgFQAGgFAJAAQAMAAAHAEIgDAGQgHgEgJAAQgFAAgEAEQgEADAAAGQAAAFAFADIAKADQAKADAEACQAIAFAAAJQAAAKgHAFQgHAFgLAAQgNAAgJgFg");
	this.shape_17.setTransform(136,6.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAMAZQgKAHgLAAQgKAAgGgEQgGgGAAgJQAAgNAQgIQgFgHAAgGQAAgGADgEQAEgFAHAAQAHAAAEAEQADAEAAAFQAAAGgEAEQgDADgGAEIAKAOIAHAIQAKgJACgPIAGAAQgBARgMAMQAHAHAIADIgDAGQgJgEgIgIgAgYANQAAAGAEAEQAEADAHAAQAIAAAIgFIgIgLIgKgMQgNAGAAAJgAgLgbQgCACAAADQAAAEAFAHQAJgFAAgHQAAgDgBgCQgCgCgEAAQgDAAgCADg");
	this.shape_18.setTransform(126.7,6.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgMAZIAAgwIAIAAIAAAJIAAAAQADgFAFgCQAEgDAGAAIAAAIQgMAAgGAIIAAAhg");
	this.shape_19.setTransform(119.1,7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgTAAQAAgIADgHQAFgJALgBQAVAAAAAYIAAADIggAAQgBARANAAQAIAAAIgDIACAFQgIAFgKAAQgVAAABgagAANgDQAAgPgMAAQgLAAgBAPIAYAAIAAAAg");
	this.shape_20.setTransform(114.6,7.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAMAZIAAgfQAAgGgCgCQgCgDgFAAQgFAAgJAFIAAAlIgIAAIAAgwIAIAAIAAAEQAJgFAHAAQAJAAAEAFQACADAAAIIAAAhg");
	this.shape_21.setTransform(109.5,7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAMAZIAAgfQAAgGgCgCQgCgDgFAAQgFAAgJAFIAAAlIgIAAIAAgwIAIAAIAAAEQAJgFAHAAQAJAAAEAFQACADAAAIIAAAhg");
	this.shape_22.setTransform(104.4,7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgTAAQAAgIADgHQAGgJALgBQATAAAAAYIAAADIggAAQAAARANAAQAIAAAIgDIACAFQgIAFgKAAQgUAAAAgagAAMgDQAAgPgLAAQgLAAgBAPIAXAAIAAAAg");
	this.shape_23.setTransform(99.3,7.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgUAiIAAhDIApAAIAAAGIggAAIAAAXIAaAAIAAAGIgaAAIAAAgg");
	this.shape_24.setTransform(94.7,6.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgFAJQAEgEABgFQgEgBAAgEQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAAAAAQABgBAAAAQABAAAAgBQABAAAAAAQAAAAABAAQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAABQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQAAAEgDAEQgDAFgDACg");
	this.shape_25.setTransform(88.1,9.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgTAAQgBgIAEgHQAFgJALgBQAUAAAAAYIAAADIgfAAQAAARAMAAQAIAAAIgDIACAFQgIAFgKAAQgUAAAAgagAAMgDQAAgPgLAAQgLAAgBAPIAXAAIAAAAg");
	this.shape_26.setTransform(84.6,7.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgSABQAAgKAEgGQAGgJALgBQAJAAAGAEIgDAGQgGgDgGAAQgGAAgDAFQgEAGAAAIQAAASANAAQAHAAAHgEIACAFQgHAGgKAAQgUAAAAgZg");
	this.shape_27.setTransform(79.8,7.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgNAZIAAgwIAJAAIAAAJIAAAAQADgFAFgCQAEgDAGAAIAAAIQgMAAgGAIIAAAhg");
	this.shape_28.setTransform(76.1,7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgUAAQABgIADgHQAGgJALgBQATAAABAYIAAADIghAAQABARANAAQAHAAAIgDIACAFQgIAFgKAAQgUAAgBgagAANgDQAAgPgMAAQgLAAgBAPIAYAAIAAAAg");
	this.shape_29.setTransform(71.6,7.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgDAiIAAgxIAHAAIAAAxgAgDgYQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAABAAQAAgBAAAAQAAAAABABQABAAAAAAQAAAAABAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAAAABQAAAAgBAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQAAAAgBgBg");
	this.shape_30.setTransform(67.8,6.2);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgVAiIAAhDIAWAAQAJAAAGAFQAGAFAAAKQAAAHgEAGQgGAGgKAAIgOAAIAAAcgAgMAAIAMAAQANAAAAgNQAAgHgEgDQgDgEgGAAIgMAAg");
	this.shape_31.setTransform(63.9,6.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgFAJQAEgEAAgFQgDgBAAgEQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAAAAAQABgBAAAAQABAAAAgBQABAAAAAAQAAAAABAAQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAABQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQAAAEgCAEQgDAFgEACg");
	this.shape_32.setTransform(57.2,9.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AAMAkIAAghQAAgEgCgDQgBgCgGAAQgFgBgJAFIAAAmIgIAAIAAhGIAIAAIAAAPIAAALIABAAQAKgFAGgBQAJAAADAGQACADAAAHIAAAig");
	this.shape_33.setTransform(53.6,6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgSABQAAgKAEgGQAGgJALgBQAJAAAGAEIgDAGQgGgDgGAAQgGAAgDAFQgEAGAAAIQAAASANAAQAHAAAHgEIACAFQgHAGgKAAQgUAAAAgZg");
	this.shape_34.setTransform(48.9,7.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AAMAZIAAgfQAAgGgCgCQgCgDgFAAQgFAAgJAFIAAAlIgIAAIAAgwIAIAAIAAAEQAJgFAHAAQAJAAAEAFQACADAAAIIAAAhg");
	this.shape_35.setTransform(44,7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgVAiIABgGIAIABQADAAACgCQACgBABgEIACgGIgSgyIAJAAIAMAoIAAAAIANgoIAIAAIgTA5QgCAHgDADQgDACgGAAIgKgBg");
	this.shape_36.setTransform(39.1,8.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgVAiIAAhDIAIAAIAAA9IAjAAIAAAGg");
	this.shape_37.setTransform(34.8,6.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgDAkIAAhGIAHAAIAABGg");
	this.shape_38.setTransform(28,6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgDAkIAAhGIAHAAIAABGg");
	this.shape_39.setTransform(25.8,6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgDAiIAAgxIAHAAIAAAxgAgDgYQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAABAAQAAgBAAAAQAAAAABABQABAAAAAAQABAAAAAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQAAAAgBgBg");
	this.shape_40.setTransform(23.4,6.2);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgMAZIAAgwIAIAAIAAAJIAAAAQADgFAFgCQAEgDAFAAIAAAIQgLAAgGAIIAAAhg");
	this.shape_41.setTransform(20.7,7);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgNAZIAAgwIAIAAIAAAJIABAAQADgFAEgCQAFgDAFAAIAAAIQgLAAgGAIIAAAhg");
	this.shape_42.setTransform(17.3,7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgUAAQAAgIAEgHQAGgJALgBQATAAAAAYIAAADIggAAQAAARAOAAQAHAAAIgDIACAFQgIAFgKAAQgUAAgBgagAAMgDQAAgPgLAAQgLAAgBAPIAXAAIAAAAg");
	this.shape_43.setTransform(12.8,7.1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AAZAiIAAgyIgWAyIgGAAIgVgxIAAAAIAAAxIgJAAIAAhDIAKAAIAXA5IABAAIAXg5IAKAAIAABDg");
	this.shape_44.setTransform(6.2,6.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.copy7, new cjs.Rectangle(0,0,218.3,14), null);


(lib.Copy6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgFAHQgEgDAAgEQAAgDAEgDQACgDADAAQAEAAADADQACADAAADQAAAEgCADQgDADgEAAQgDAAgCgDg");
	this.shape.setTransform(256.4,34.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPAiIAAg4IgNAAIAAgIIANgEIAFgTIAJgCIAAAWIAaAAIAAALIgaAAIAAA0QAAAOALAAQAGAAALgDIACAKQgKAFgMAAQgWAAAAgWg");
	this.shape_1.setTransform(251.5,30.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAVAtIAAg5QAAgLgCgDQgEgGgJAAQgLAAgPAJIAABEIgPAAIAAhXIAPAAIAAAIIAAAAQAQgKAOAAQAQAAAGAJQAEAGAAANIAAA9g");
	this.shape_2.setTransform(243.6,31);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgdAmQgFgHgBgJQABgMAIgIQAIgFANgBIAagCIAAgGQAAgMgEgEQgEgFgLAAQgLAAgQAFIgCgKQAPgGASgBQAeAAAAAeIAAA7IgOAAIgBgJIAAgBQgOAMgPAAQgOgBgHgHgAgBAEQgRABAAAPQgBAPARAAQAKAAANgLIAAgVg");
	this.shape_3.setTransform(234.4,31.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAVAsIgNgpIgIgeIgBAAIgIAeIgLApIgQAAIgahXIAPAAIAMAsIAHAcIABAAIAHgdIANgrIANAAIAPAtIAHAbIABAAIAHgbIAMgtIAPAAIgaBXg");
	this.shape_4.setTransform(223.7,31.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgeAkQgEgGAAgNIAAg9IAPAAIAAA5QAAALACAEQADAFAKAAQAMAAAMgLIAAhCIAPAAIAABXIgOAAIgBgKQgOAMgOAAQgQAAgGgJg");
	this.shape_5.setTransform(207.9,31.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgeAgQgIgLAAgUQAAgTAJgMQAKgPAUAAQAUAAAKAPQAIAMAAASQAAAUgIALQgLAPgUAAQgUAAgKgOgAgWABQgBAPAFAIQAGAKANAAQAWAAABghQgBgigWAAQgXAAAAAig");
	this.shape_6.setTransform(198.6,31.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgnA8IACgLIAPACQAFAAADgCQAEgDADgIIADgKIgghaIAPAAIAXBIIABAAIAWhIIAPAAIgjBnQgEAMgFAFQgGAGgKAAQgIAAgLgEg");
	this.shape_7.setTransform(189.8,33.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgkAAQAAgPAHgMQAKgSAUAAQAkAAAAAqIAAAGIg6AAQAAAfAYAAQANAAAQgGIADAKQgPAIgSAAQgmAAAAgugAAXgFQAAgdgVAAQgVAAgBAdIArAAIAAAAg");
	this.shape_8.setTransform(176.5,31.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgQBBIAAhMIgNAAIAAgIIANgDIAAgPQAAgbAbAAQAKAAAJACIgCALIgOgBQgQAAAAAPIAAAPIAYAAIAAALIgYAAIAABMg");
	this.shape_9.setTransform(169.2,29);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgGA8IAAhXIANAAIAABXgAgGgrQgDgDAAgEQAAgEADgDQADgCADAAQAEAAADACQADADAAAEQAAAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_10.setTransform(163.3,29.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgGBAIAAh/IANAAIAAB/g");
	this.shape_11.setTransform(158.9,29.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgkAAQAAgPAHgMQAKgSAUAAQAkAAAAAqIAAAGIg6AAQAAAfAYAAQANAAAPgGIAEAKQgPAIgSAAQgmAAAAgugAAXgFQAAgdgVAAQgVAAgBAdIArAAIAAAAg");
	this.shape_12.setTransform(147.6,31.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAVBAIAAg6QAAgKgCgDQgEgGgJAAQgLAAgPAJIAABEIgPAAIAAh/IAPAAIAAAdIgBASIACABQASgKALAAQAQAAAGAJQAEAGAAAMIAAA+g");
	this.shape_13.setTransform(138.4,29.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgPAiIAAg4IgNAAIAAgIIANgEIAFgTIAJgCIAAAWIAaAAIAAALIgaAAIAAA0QAAAOALAAQAGAAALgDIACAKQgKAFgMAAQgWAAAAgWg");
	this.shape_14.setTransform(130.6,30.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgkAAQAAgPAHgMQAKgSAVAAQAjAAAAAqIAAAGIg6AAQAAAfAYAAQAOAAAOgGIAEAKQgPAIgSAAQgmAAAAgugAAXgFQAAgdgVAAQgUAAgDAdIAsAAIAAAAg");
	this.shape_15.setTransform(118,31.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgIAsIgfhXIAPAAIAPAsIAJAgIABAAIAKghIAOgrIAPAAIgfBXg");
	this.shape_16.setTransform(109.5,31.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgGA8IAAhXIANAAIAABXgAgGgrQgDgDAAgEQAAgEADgDQADgCADAAQAEAAADACQADADAAAEQAAAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_17.setTransform(103,29.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgGBAIAAh/IANAAIAAB/g");
	this.shape_18.setTransform(98.7,29.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgeAkQgEgGAAgNIAAg9IAPAAIAAA5QAAALACAEQADAFAKAAQAMAAAMgLIAAhCIAPAAIAABXIgOAAIgBgKQgOAMgOAAQgQAAgGgJg");
	this.shape_19.setTransform(87.3,31.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgeAgQgIgLAAgUQAAgTAJgMQAKgPAUAAQAUAAAKAPQAIAMAAASQAAAUgIALQgLAPgUAAQgUAAgKgOgAgWABQgBAPAFAIQAGAKANAAQAWAAABghQgBgigWAAQgXAAAAAig");
	this.shape_20.setTransform(78,31.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgnA8IACgLIAPACQAFAAADgCQAEgDADgIIADgKIgghaIAPAAIAXBIIABAAIAWhIIAPAAIgjBnQgEAMgFAFQgGAGgKAAQgIAAgLgEg");
	this.shape_21.setTransform(69.2,33.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgkBAIAAh9IAOAAIAAAHIABABQAMgKANAAQAhAAAAAsQAAAUgIANQgJAOgSAAQgPAAgJgGIAAAqgAgLgwQgHADgEAEIAAA0IAKAEQAHACAFAAQAWAAAAgkQAAgggWAAQgEAAgHADg");
	this.shape_22.setTransform(55.8,32.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgGBAIAAh/IANAAIAAB/g");
	this.shape_23.setTransform(48.9,29.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgkAAQAAgPAHgMQAKgSAVAAQAjAAAAAqIAAAGIg6AAQAAAfAYAAQAOAAAOgGIAEAKQgPAIgSAAQgmAAAAgugAAXgFQAAgdgVAAQgUAAgDAdIAsAAIAAAAg");
	this.shape_24.setTransform(42.4,31.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAVBAIAAg6QAAgKgCgDQgEgGgJAAQgLAAgPAJIAABEIgPAAIAAh/IAPAAIAAAdIgBASIACABQASgKALAAQAQAAAGAJQAEAGAAAMIAAA+g");
	this.shape_25.setTransform(33.2,29.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgeAgQgIgLAAgUQAAgTAJgMQALgPATAAQAUAAAKAPQAIAMAAASQAAAUgJALQgKAPgUAAQgUAAgKgOgAgXABQABAPAEAIQAFAKAOAAQAXAAgBghQABgigXAAQgYAAAAAig");
	this.shape_26.setTransform(19,31.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgPAiIAAg4IgNAAIAAgIIANgEIAFgTIAJgCIAAAWIAaAAIAAALIgaAAIAAA0QAAAOALAAQAGAAALgDIACAKQgKAFgMAAQgWAAAAgWg");
	this.shape_27.setTransform(11.1,30.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgkAAQAAgPAHgMQAKgSAVAAQAjAAAAAqIAAAGIg6AAQAAAfAYAAQAOAAAOgGIAEAKQgPAIgSAAQgmAAAAgugAAXgFQAAgdgVAAQgUAAgDAdIAsAAIAAAAg");
	this.shape_28.setTransform(255.7,11.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AghABQAAgRAHgMQAKgRAVAAQAQAAALAHIgFALQgLgGgKAAQgMAAgGAKQgHAJABAPQAAAhAXAAQAMAAANgHIAFAKQgNAJgSAAQglAAAAgtg");
	this.shape_29.setTransform(247.3,11.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AAVAtIAAg5QAAgLgCgDQgEgGgJAAQgLAAgPAJIAABEIgPAAIAAhXIAPAAIAAAIIAAAAQAQgKAOAAQAQAAAGAKQAEAFAAAOIAAA8g");
	this.shape_30.setTransform(238.3,11);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgdAlQgGgGABgJQgBgMAJgIQAIgFANgBIAagCIAAgGQAAgMgEgEQgEgFgLAAQgLAAgPAFIgEgKQARgHAQAAQAeABABAdIAAA7IgOAAIAAgJIgBgBQgOALgPAAQgOAAgHgIgAgBAEQgRABgBAPQAAAPAQAAQALABANgMIAAgVg");
	this.shape_31.setTransform(229.2,11.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AglAVQABgvAjAAQANABALAGIAAgsIAOAAIAAB+IgNAAIAAgIIgBgBQgNAKgOAAQggAAgBgrgAgVAVQgBAgAWAAQAEABAIgDQAHgDAEgEIAAg0QgKgGgNAAQgVAAAAAjg");
	this.shape_32.setTransform(220.2,9.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgGA8IAAhXIANAAIAABXgAgGgrQgDgDAAgEQAAgEADgDQADgCADAAQAEAAADACQADADAAAEQAAAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_33.setTransform(213.3,9.5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgeAkQgEgGAAgNIAAg9IAPAAIAAA5QAAALACAEQADAFAKAAQAMAAAMgLIAAhCIAPAAIAABXIgOAAIgBgKQgOAMgOAAQgQAAgGgJg");
	this.shape_34.setTransform(206.5,11.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AghA5QgJgGABgKQgBgOANgGQgMgDAAgMQAAgGAGgEQAEgGAHgBIAAgBQgLgFAAgQQAAgPALgIQAJgIANAAQAKAAAGACIAcgCIAAALIgPAAIgBABQAHAGAAAMQAAANgKAIQgJAIgQAAIgLAAQgGAAgFADQgDADAAAEQgBAHALAAIAVAAQAkAAAAAXQAAANgMAIQgMAJgUAAQgTAAgKgIgAgYAcQgDAEAAAGQAAAPAZAAQALABAIgFQAIgEAAgJQAAgOgWAAIgTAAQgFACgDAEgAgPgvQgGAEAAAJQAAAJAGAFQAFAEAJABQAIgBAFgEQAGgFAAgKQAAgHgFgFQgEgFgKAAQgJAAgFAFg");
	this.shape_35.setTransform(197.3,13);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AglAVQABgvAjAAQANABALAGIAAgsIAOAAIAAB+IgNAAIAAgIIgBgBQgNAKgOAAQggAAgBgrgAgVAVQgBAgAWAAQAEABAIgDQAHgDAEgEIAAg0QgKgGgNAAQgVAAAAAjg");
	this.shape_36.setTransform(182.9,9.2);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AAVAtIAAg5QAAgLgCgDQgEgGgJAAQgLAAgPAJIAABEIgPAAIAAhXIAPAAIAAAIIAAAAQAQgKAOAAQAQAAAGAKQAEAFAAAOIAAA8g");
	this.shape_37.setTransform(173.6,11);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgdAlQgGgGABgJQAAgMAIgIQAIgFANgBIAagCIAAgGQAAgMgEgEQgEgFgLAAQgLAAgPAFIgDgKQAQgHAQAAQAfABAAAdIAAA7IgOAAIgBgJIAAgBQgNALgQAAQgOAAgHgIgAgBAEQgRABAAAPQAAAPAPAAQALABANgMIAAgVg");
	this.shape_38.setTransform(164.5,11.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgkAAQAAgPAHgMQAKgSAUAAQAkAAAAAqIAAAGIg6AAQAAAfAZAAQANAAAPgGIADAKQgPAIgSAAQgmAAAAgugAAXgFQAAgdgVAAQgVAAgBAdIArAAIAAAAg");
	this.shape_39.setTransform(150.9,11.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgiABQAAgRAIgMQAKgRAWAAQAPAAALAHIgFALQgLgGgKAAQgLAAgHAKQgGAJgBAPQABAhAXAAQAMAAANgHIAEAKQgMAJgSAAQgmAAAAgtg");
	this.shape_40.setTransform(142.5,11.1);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgGA8IAAhXIANAAIAABXgAgGgrQgDgDAAgEQAAgEADgDQADgCADAAQAEAAADACQADADAAAEQAAAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_41.setTransform(135.9,9.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgIAsIgfhXIAPAAIAPAtIAJAeIABAAIAKggIAPgrIAOAAIgfBXg");
	this.shape_42.setTransform(129.5,11.1);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgkAVQAAgvAjAAQANABAKAGIAAgsIAPAAIAAB+IgNAAIAAgIIgBgBQgNAKgOAAQghAAABgrgAgWAVQAAAgAWAAQAEABAIgDQAHgDADgEIAAg0QgJgGgNAAQgVAAgBAjg");
	this.shape_43.setTransform(120.6,9.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgdAlQgGgGAAgJQAAgMAJgIQAIgFAOgBIAZgCIAAgGQAAgMgEgEQgEgFgLAAQgLAAgQAFIgDgKQARgHARAAQAdABAAAdIAAA7IgNAAIAAgJIgBgBQgOALgQAAQgNAAgHgIgAgBAEQgSABAAAPQABAPAQAAQAKABANgMIAAgVg");
	this.shape_44.setTransform(111.4,11.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AghA5QgJgGABgKQAAgOAMgGQgLgDAAgMQAAgGAEgEQAFgGAHgBIAAgBQgMgFAAgQQAAgPAMgIQAJgIANAAQAKAAAGACIAcgCIAAALIgQAAIAAABQAHAGAAAMQAAANgKAIQgKAIgPAAIgLAAQgGAAgEADQgFADAAAEQAAAHALAAIAVAAQAkAAAAAXQAAANgMAIQgNAJgTAAQgUAAgJgIgAgXAcQgEAEAAAGQAAAPAZAAQALABAIgFQAIgEAAgJQAAgOgWAAIgTAAQgEACgDAEgAgPgvQgFAEgBAJQABAJAFAFQAGAEAIABQAIgBAFgEQAGgFAAgKQAAgHgFgFQgEgFgKAAQgJAAgFAFg");
	this.shape_45.setTransform(97.7,13);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AAVAtIAAg5QAAgLgCgDQgEgGgJAAQgLAAgPAJIAABEIgPAAIAAhXIAPAAIAAAIIAAAAQAQgKAOAAQAQAAAGAKQAEAFAAAOIAAA8g");
	this.shape_46.setTransform(88.2,11);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgGA8IAAhXIANAAIAABXgAgGgrQgDgDAAgEQAAgEADgDQADgCADAAQAEAAADACQADADAAAEQAAAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_47.setTransform(81.3,9.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgPAiIAAg4IgNAAIAAgIIANgEIAFgTIAJgCIAAAWIAaAAIAAALIgaAAIAAA0QAAAOALAAQAGAAALgDIACAKQgKAFgMAAQgWAAAAgWg");
	this.shape_48.setTransform(75.9,10.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AggAnIAFgKQANAGAOAAQATAAAAgOQAAgHgGgEQgEgCgJgDQgPgFgFgDQgIgGgBgLQABgMAIgHQAJgGANAAQAQAAALAHIgFAKQgMgFgKAAQgRAAAAANQAAAIASAGQAPAEAFADQAKAHAAANQAAAMgKAHQgJAGgOAAQgUAAgMgHg");
	this.shape_49.setTransform(68.6,11.1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgkAAQAAgPAHgMQAKgSAUAAQAkAAAAAqIAAAGIg6AAQAAAfAZAAQANAAAPgGIADAKQgPAIgSAAQgmAAAAgugAAXgFQAAgdgVAAQgVAAgBAdIArAAIAAAAg");
	this.shape_50.setTransform(60.1,11.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgIAsIgfhXIAPAAIAPAtIAJAeIABAAIAKggIAOgrIAPAAIggBXg");
	this.shape_51.setTransform(51.6,11.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AAVAtIAAg5QAAgLgCgDQgEgGgJAAQgLAAgPAJIAABEIgPAAIAAhXIAPAAIAAAIIAAAAQAQgKAOAAQAQAAAGAKQAEAFAAAOIAAA8g");
	this.shape_52.setTransform(42.8,11);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgGA8IAAhXIANAAIAABXgAgGgrQgDgDAAgEQAAgEADgDQADgCADAAQAEAAADACQADADAAAEQAAAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_53.setTransform(35.9,9.5);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgPAiIAAg4IgNAAIAAgIIANgEIAFgTIAJgCIAAAWIAaAAIAAALIgaAAIAAA0QAAAOALAAQAGAAALgDIACAKQgKAFgMAAQgWAAAAgWg");
	this.shape_54.setTransform(25.6,10.1);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgkAAQAAgPAHgMQAKgSAUAAQAkAAAAAqIAAAGIg6AAQAAAfAYAAQANAAAPgGIAEAKQgPAIgSAAQgmAAAAgugAAXgFQAAgdgVAAQgUAAgDAdIAsAAIAAAAg");
	this.shape_55.setTransform(17.9,11.1);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgsABQAAgYALgRQAPgWAdAAQAVAAAMAIIgFALQgNgHgPAAQgTAAgKAOQgKAOAAAXQAAAyAlAAQANAAAJgFIAAgoIgWAAIAAgKIAkAAIAAA5QgPAKgWAAQg0AAAAg+g");
	this.shape_56.setTransform(7.6,9.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Copy6, new cjs.Rectangle(0,0,262.3,42), null);


(lib.copy5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0052C2").s().p("AgqArIAGgRQATAGAQAAQAQAAAAgLQAAgFgGgDIgLgEQgTgGgGgDQgLgHAAgNQAAgPALgHQALgIASAAQAVAAAOAHIgGASQgOgFgNAAQgOAAAAAJQAAAFARAFQARAEAHAGQAMAIAAAOQAAAegtAAQgXAAgRgIg");
	this.shape.setTransform(132.9,-9.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0052C2").s().p("AgHAYIgEgvIAXAAIgFAvg");
	this.shape_1.setTransform(125.7,-16.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0052C2").s().p("AgmAkQgLgNAAgXQAAgVAMgOQANgPAYAAQAaAAANAPQALANAAAWQAAAXgMANQgMAPgaAAQgZAAgNgPgAgTAAQAAAPAEAHQAEAJALAAQAUAAAAgfQAAgegUAAQgTAAAAAeg");
	this.shape_2.setTransform(117.5,-9.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0052C2").s().p("AASBHIAAg8QAAgJgCgDQgDgEgJAAQgJgBgMAHIAABGIgdAAIAAiNIAcAAIAAAfIAAAVIABACQASgMAPAAQASAAAHAKQAGAHAAAQIAABCg");
	this.shape_3.setTransform(106.1,-12.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0052C2").s().p("AATAxIgMgqIgHgfIAAAAIgHAfIgLAqIghAAIgbhhIAdAAIALAtIAGAdIABAAIAGgeIAMgsIAaAAIANAuIAHAcIABAAIAGgcIALguIAcAAIgbBhg");
	this.shape_4.setTransform(92.2,-9.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0052C2").s().p("AgLAKQgEgEAAgGQAAgFAFgEQAEgEAGAAQAHAAAFAEQAEAEAAAFQAAAGgEAEQgFAEgHAAQgGAAgFgEg");
	this.shape_5.setTransform(180.9,16.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0052C2").s().p("AgXAiIAAgyIgOAAIAAgQIAQgFIAHgXIASgCIAAAbIAdAAIAAATIgdAAIAAArQAAAIADAEQADADAHAAQAFAAAMgCIAEASQgNAGgPAAQghAAAAgeg");
	this.shape_6.setTransform(174.4,11.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0052C2").s().p("AASAyIAAg8QAAgIgCgEQgDgFgJAAQgJAAgMAHIAABGIgdAAIAAhhIAbAAIABAJIAAAAQASgLAQAAQASAAAHAKQAGAHAAAQIAABCg");
	this.shape_7.setTransform(164.6,13);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0052C2").s().p("AguABQAAgTAKgOQANgSAZAAQAsAAABAwIAAAJIg/AAQAAAXAXAAQAPAAARgHIAGASQgTAKgXAAQgxAAAAgygAAVgKQgBgVgRAAQgRAAgCAVIAlAAIAAAAg");
	this.shape_8.setTransform(153.6,13.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#0052C2").s().p("AggAyIAAhhIAbAAIAAAVIABAAQALgXAaAAIAAAZQgWABgPATIAAA2g");
	this.shape_9.setTransform(144.7,13);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#0052C2").s().p("AgmApQgGgIAAgKQAAgPAKgIQAKgHAQgBIAagCIAAgCQAAgJgEgEQgEgEgKAAQgPAAgQAFIgEgSQATgIAWAAQAnAAAAAiIAABBIgZAAIgBgKIgBAAQgOAMgSAAQgQAAgIgKgAgBAHQgOABAAAMQAAANAOAAQAJAAAKgJIAAgTg");
	this.shape_10.setTransform(134.5,13.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#0052C2").s().p("AgwBHIAAiLIAbAAIABAIIABABQAOgLAOAAQAnAAABAyQAAAXgKANQgLAPgWAAQgPAAgKgGIAAAugAgKgvIgJAFIAAAvQAJAGAKgBQAUABAAggQAAgcgUAAQgDAAgHACg");
	this.shape_11.setTransform(123.7,15.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#0052C2").s().p("AgmApQgGgIAAgKQAAgPAKgIQAKgHAQgBIAagCIAAgCQAAgJgEgEQgEgEgKAAQgPAAgQAFIgEgSQATgIAWAAQAnAAAAAiIAABBIgZAAIgBgKIgBAAQgOAMgSAAQgQAAgIgKgAgBAHQgOABAAAMQAAANAOAAQAJAAAKgJIAAgTg");
	this.shape_12.setTransform(106.3,13.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0052C2").s().p("AghAyIAAhhIAcAAIAAAVIACAAQAKgXAbAAIAAAZQgXABgOATIAAA2g");
	this.shape_13.setTransform(91.9,13);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#0052C2").s().p("AgmAkQgLgNAAgXQAAgVAMgOQANgPAYAAQAaAAANAPQALANAAAWQAAAXgMANQgMAPgaAAQgZAAgNgPgAgTAAQAAAPAEAHQAEAJALAAQAUAAAAgfQAAgegUAAQgTAAAAAeg");
	this.shape_14.setTransform(81.6,13.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#0052C2").s().p("AgYBJIAAhPIgOAAIAAgQIAOgEIAAgMQAAghAkAAQAPAAAMADIgDATQgJgCgIAAQgQABAAANIAAAMIAcAAIAAATIgcAAIgBBPg");
	this.shape_15.setTransform(72.3,10.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#0052C2").s().p("AgqA+QgJgHAAgLQAAgGAEgGQAEgGAGgDQgHgCgDgGQgEgFABgHQABgFAFgFQAEgFAIgCIAAgBQgLgGAAgQQAAgRANgJQAMgIARAAQAKAAAIACIAjgCIAAAQIgPAAIgBABQAFAGAAAKQAAAPgMAIQgMAJgRAAIgMAAQgNAAAAAHQAAAGAJAAIAhAAQAQAAAJAHQAJAHAAANQAAAQgOAKQgQAMgaAAQgaAAgLgKgAgVAfQgDAEAAADQAAAOAVAAQALAAAHgFQAGgEAAgGQAAgLgQAAIgUAAQgDABgDAEgAgLgvQgDAEAAAFQAAAGADAEQAEAEAGAAQAFAAAEgEQAEgEAAgGQAAgGgDgDQgEgFgFAAQgHAAgEAFg");
	this.shape_16.setTransform(56.5,15.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#0052C2").s().p("AASAyIAAg8QAAgIgCgEQgDgFgJAAQgJAAgMAHIAABGIgdAAIAAhhIAbAAIABAJIAAAAQASgLAQAAQASAAAHAKQAGAHAAAQIAABCg");
	this.shape_17.setTransform(45.1,13);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#0052C2").s().p("AgNBHIAAhiIAbAAIAABigAgLgsQgFgEAAgGQAAgHAFgEQAEgFAHAAQAIAAAEAFQAFAEAAAHQAAAGgFAEQgEAFgIAAQgHAAgEgFg");
	this.shape_18.setTransform(36.5,11);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#0052C2").s().p("AggAyIAAhhIAbAAIABAVIABAAQAKgXAaAAIAAAZQgXABgNATIAAA2g");
	this.shape_19.setTransform(30.1,13);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#0052C2").s().p("AgmApQgGgIAAgKQAAgPAKgIQAKgHAQgBIAagCIAAgCQAAgJgEgEQgEgEgKAAQgPAAgQAFIgEgSQATgIAWAAQAnAAAAAiIAABBIgZAAIgBgKIgBAAQgOAMgSAAQgQAAgIgKgAgBAHQgOABAAAMQAAANAOAAQAJAAAKgJIAAgTg");
	this.shape_20.setTransform(19.9,13.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#0052C2").s().p("AgpABQAAgUAJgNQANgSAZAAQAVAAANAJIgJAUQgMgHgMAAQgSAAgBAdQAAAcATAAQANAAAPgHIAHATQgQAKgVAAQguAAAAgyg");
	this.shape_21.setTransform(10,13.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.copy5, new cjs.Rectangle(3,-22,182.7,47), null);


(lib.copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0052C2").s().p("AgLAKQgEgEAAgGQAAgFAFgEQAEgEAGAAQAHAAAFAEQAEAEAAAFQAAAGgEAEQgFAEgHAAQgGAAgFgEg");
	this.shape.setTransform(165.5,39.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0052C2").s().p("AgXAjIAAg0IgOAAIAAgPIAPgFIAHgYIATgCIAAAbIAcAAIAAATIgcAAIAAAsQAAAIADADQADAEAHAAQAGAAALgCIAEASQgMAGgQgBQghAAAAgcg");
	this.shape_1.setTransform(159.1,34.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0052C2").s().p("AASAyIAAg8QAAgIgCgEQgDgFgJAAQgJAAgMAHIAABGIgdAAIAAhhIAbAAIABAJIAAAAQASgLAQAAQASAAAHAKQAGAHAAAQIAABCg");
	this.shape_2.setTransform(149.3,36);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0052C2").s().p("AgtABQAAgUAJgNQAMgSAZAAQAuAAgBAwIAAAKIg/AAQABAWAXAAQAPAAAQgGIAGASQgRAJgZAAQgvAAAAgygAAUgJQAAgXgSAAQgRAAgCAXIAlAAIAAAAg");
	this.shape_3.setTransform(138.2,36.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0052C2").s().p("AghAyIAAhhIAcAAIABAVIABAAQAKgXAbAAIAAAZQgYABgNATIAAA2g");
	this.shape_4.setTransform(129.3,36);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0052C2").s().p("AgmApQgGgIAAgLQAAgOAKgIQAKgHAQgBIAagCIAAgCQAAgJgEgEQgEgEgKAAQgPAAgQAFIgEgSQATgIAWAAQAnAAAAAiIAABBIgZAAIgBgKIgBAAQgOAMgSAAQgQAAgIgKgAgBAGQgOACAAAMQAAAMAOAAQAJAAAKgIIAAgTg");
	this.shape_5.setTransform(119.1,36.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0052C2").s().p("AgwBHIAAiMIAbAAIABAJIABABQAOgLAPAAQAnAAgBAyQAAAXgJANQgLAPgVAAQgQAAgKgGIAAAugAgJgvIgKAFIAAAvQAJAFAKAAQATAAAAgfQAAgcgSgBQgEABgGACg");
	this.shape_6.setTransform(108.3,38.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0052C2").s().p("AgqA+QgJgHAAgLQAAgGAEgGQAEgGAGgDQgHgCgDgGQgEgFABgHQABgFAFgFQAEgFAIgCIAAgBQgLgGAAgQQAAgRANgJQAMgIARAAQAKAAAIACIAjgCIAAAQIgPAAIgBABQAFAGAAAKQAAAPgMAIQgMAJgRAAIgMAAQgNAAAAAHQAAAGAJAAIAhAAQAQAAAJAHQAJAHAAANQAAAQgOAKQgQAMgaAAQgaAAgLgKgAgVAfQgDAEAAADQAAAOAVAAQALAAAHgFQAGgEAAgGQAAgLgQAAIgUAAQgDABgDAEgAgLgvQgDAEAAAFQAAAGADAEQAEAEAGAAQAFAAAEgEQAEgEAAgGQAAgGgDgDQgEgFgFAAQgHAAgEAFg");
	this.shape_7.setTransform(91.2,38.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0052C2").s().p("AASAyIAAg8QAAgIgCgEQgDgFgJAAQgJAAgMAHIAABGIgdAAIAAhhIAbAAIABAJIAAAAQASgLAQAAQASAAAHAKQAGAHAAAQIAABCg");
	this.shape_8.setTransform(79.8,36);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#0052C2").s().p("AgNBHIAAhiIAbAAIAABigAgLgrQgFgFAAgGQAAgHAFgEQAEgEAHAAQAIAAAEAEQAFAEAAAHQAAAGgFAFQgEAEgIAAQgHAAgEgEg");
	this.shape_9.setTransform(71.1,34);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#0052C2").s().p("AggAyIAAhhIAbAAIABAVIABAAQAKgXAaAAIAAAZQgXABgNATIAAA2g");
	this.shape_10.setTransform(64.7,36);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#0052C2").s().p("AgmApQgGgIAAgLQAAgOAKgIQAKgHAQgBIAagCIAAgCQAAgJgEgEQgEgEgKAAQgPAAgQAFIgEgSQATgIAWAAQAnAAAAAiIAABBIgZAAIgBgKIgBAAQgOAMgSAAQgQAAgIgKgAgBAGQgOACAAAMQAAAMAOAAQAJAAAKgIIAAgTg");
	this.shape_11.setTransform(54.5,36.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#0052C2").s().p("AgpABQAAgUAJgNQANgSAZAAQAVAAANAJIgJAUQgMgHgMAAQgSAAgBAdQAAAcATAAQANAAAPgHIAHATQgQAKgVAAQguAAAAgyg");
	this.shape_12.setTransform(44.7,36.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0052C2").s().p("AgmApQgGgIAAgLQAAgOAKgIQAKgHAQgBIAagCIAAgCQAAgJgEgEQgEgEgKAAQgPAAgQAFIgEgSQATgIAWAAQAnAAAAAiIAABBIgZAAIgBgKIgBAAQgOAMgSAAQgQAAgIgKgAgBAGQgOACAAAMQAAAMAOAAQAJAAAKgIIAAgTg");
	this.shape_13.setTransform(28.2,36.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#0052C2").s().p("AgqArIAHgSQASAHAQAAQAQAAAAgLQAAgFgGgDIgLgFQgTgFgGgDQgLgIAAgMQAAgPALgHQALgIASAAQAVAAAOAIIgGASQgOgGgOAAQgNAAAAAJQAAAFARAFQAQAEAIAGQAMAHAAAQQAAAdgtAAQgYAAgQgIg");
	this.shape_14.setTransform(149.9,12.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#0052C2").s().p("AgHAYIgEgvIAXAAIgFAvg");
	this.shape_15.setTransform(142.7,5.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#0052C2").s().p("AgmAkQgLgNAAgXQAAgVAMgOQANgPAYAAQAaAAANAPQALANAAAWQAAAXgMANQgMAPgaAAQgZAAgNgPgAgTAAQAAAPAEAHQAEAJALAAQAUAAAAgfQAAgegUAAQgTAAAAAeg");
	this.shape_16.setTransform(134.5,12.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#0052C2").s().p("AASBIIAAg9QAAgJgCgCQgDgGgJAAQgJAAgMAGIAABIIgdAAIAAiOIAcAAIAAAgIAAAVIABAAQASgLAPAAQASAAAHAKQAGAIAAAPIAABDg");
	this.shape_17.setTransform(123.1,9.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#0052C2").s().p("AATAxIgMgqIgHgfIAAAAIgHAfIgLAqIghAAIgbhhIAdAAIALAtIAGAdIABAAIAGgeIAMgsIAaAAIANAuIAHAcIABAAIAGgcIALguIAcAAIgbBhg");
	this.shape_18.setTransform(109.2,12.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.copy4, new cjs.Rectangle(21,0,149.3,48), null);


(lib.copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#009CDE").s().p("AgoApQgFgIAAgQIAAhCIAdAAIAAA8QAAAIACAEQADAFAIAAQAKAAAKgJIAAhEIAdAAIAABhIgbAAIgBgKIgBgBQgPANgRAAQgSAAgHgJg");
	this.shape.setTransform(53.4,12.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#009CDE").s().p("AgmAkQgLgNAAgXQAAgVAMgOQANgPAYAAQAaAAANAPQALANAAAWQAAAXgMANQgMAPgaAAQgZAAgNgPgAgTAAQAAAPAEAHQAEAJALAAQAUAAAAgfQAAgegUAAQgTAAAAAeg");
	this.shape_1.setTransform(42.1,12.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#009CDE").s().p("AgyBDIADgTIASACQAMAAAEgLIACgIIglhlIAdAAIAUBGIACAAIAUhGIAcAAIgnBwQgGASgJAHQgIAEgPAAQgJAAgPgEg");
	this.shape_2.setTransform(31.3,14.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0052C2").s().p("AguABQAAgUAKgNQAMgSAZAAQAuAAgBAwIAAAJIg/AAQABAXAXAAQAPAAAQgHIAGASQgRAKgZAAQgvAAgBgygAAUgKQAAgVgSAAQgRAAgCAVIAlAAIAAAAg");
	this.shape_3.setTransform(15,12.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0052C2").s().p("AASBIIAAg9QAAgJgCgCQgDgGgJAAQgJAAgMAGIAABIIgdAAIAAiOIAcAAIAAAgIAAAVIABAAQASgLAPAAQASAAAHAKQAGAIAAAPIAABDg");
	this.shape_4.setTransform(3.9,9.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0052C2").s().p("AgOBFIAAhzIgrAAIAAgWIBzAAIAAAWIgrAAIgBBzg");
	this.shape_5.setTransform(-7.9,10.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.copy3, new cjs.Rectangle(-16,0,77.2,24), null);


(lib.copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#009CDE").s().p("AgQAPQgGgGAAgJQAAgJAGgFQAGgHAKAAQALAAAGAHQAGAFAAAJQAAAJgGAGQgGAGgLAAQgKAAgGgGg");
	this.shape.setTransform(126.4,22.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#009CDE").s().p("Ag8A8QgIgKAAgYIAAhlIArAAIAABbQAAAMAEAHQAEAHAMAAQAPAAAQgNIAAhoIArAAIAACTIgoAAIgBgQIgBAAQgXATgaAAQgbABgLgQg");
	this.shape_1.setTransform(114.3,17.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#009CDE").s().p("Ag5A2QgRgTAAgjQAAghASgUQATgXAmAAQAmAAATAXQARAUAAAhQAAAigRAUQgUAXgmAAQgnAAgSgXgAgeAAQAAAWAHALQAGAOASAAQAdAAAAgvQAAgugdAAQgeAAgBAug");
	this.shape_2.setTransform(97.3,17.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#009CDE").s().p("AhMBkIAHgcQASAEAHAAQASAAAGgRIAEgNIg5iYIAtAAIAeBpIABAAIAehpIArAAIg5CpQgKAcgPAJQgKAGgXAAQgNABgYgHg");
	this.shape_3.setTransform(81.1,20.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0052C2").s().p("AAcBrIAAhbQgBgNgDgEQgEgIgNAAQgPAAgSAKIAABqIgsAAIAAjVIArAAIAAAwIgBAfIACACQAbgRAXAAQAcAAAKAPQAJALAAAXIAABkg");
	this.shape_4.setTransform(56.2,13.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0052C2").s().p("AgjAzIAAhNIgVAAIAAgXIAYgHIAKgjIAcgDIAAAoIArAAIAAAcIgrAAIAABCQAAAMAEAFQAFAGALAAQAIAAASgEIAFAcQgTAIgXAAQgyAAAAgsg");
	this.shape_5.setTransform(41.7,15.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0052C2").s().p("AgVBqIAAiTIAqAAIAACTgAgShCQgGgGAAgKQAAgKAGgGQAHgHALAAQAMAAAGAHQAHAGAAAKQAAAKgHAGQgGAHgMAAQgLAAgHgHg");
	this.shape_6.setTransform(31.1,13.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0052C2").s().p("AAcBKIgRg/IgLgvIgCAAIgJAvIgQA/IgyAAIgoiTIAqAAIARBEIAJAtIABAAIAKguIARhDIApAAIATBFIAKArIACAAIAIgrIARhFIAqAAIgoCTg");
	this.shape_7.setTransform(14.3,17.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.copy2, new cjs.Rectangle(0,0,132.4,34), null);


(lib.copy1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0052C2").s().p("Ag/BBIAJgbQAcAJAZABQAXgBAAgQQAAgHgJgEIgSgHQgbgJgJgFQgRgKAAgUQAAgVAQgMQARgMAdAAQAeAAAWAMIgKAaQgUgIgVAAQgUAAAAAOQAAAIAZAGQAZAIALAHQASAMAAAXQABAshEAAQgkABgYgMg");
	this.shape.setTransform(138,17.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0052C2").s().p("AgjAzIAAhNIgVAAIAAgXIAYgHIAKgjIAcgDIAAAoIArAAIAAAcIgrAAIAABCQAAAMAEAFQAFAGALAAQAIAAASgEIAFAcQgTAIgXAAQgyAAAAgsg");
	this.shape_1.setTransform(124.6,15.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0052C2").s().p("AgxBLIAAiSIAoAAIACAfIABABQAQgkAoAAIAAAnQgjAAgWAeIAABRg");
	this.shape_2.setTransform(113.4,17);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0052C2").s().p("Ag6A+QgJgMAAgQQAAgWAQgMQAOgLAZgCIAngCIAAgEQAAgNgFgGQgHgGgPAAQgXAAgXAHIgHgaQAdgNAiAAQA6AAAAA0IAABiIgmAAIgCgPIAAAAQgVASgcAAQgZAAgMgPgAgCAKQgUACAAASQAAATAUAAQAOAAAPgNIAAgcg");
	this.shape_3.setTransform(98,17.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0052C2").s().p("AgjAzIAAhNIgVAAIAAgXIAYgHIAKgjIAcgDIAAAoIArAAIAAAcIgrAAIAABCQAAAMAEAFQAFAGALAAQAIAAASgEIAFAcQgTAIgXAAQgyAAAAgsg");
	this.shape_4.setTransform(84.3,15.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0052C2").s().p("AhABBIAKgbQAcAJAZABQAXgBAAgQQAAgHgIgEIgSgHQgbgJgKgFQgQgKAAgUQAAgVAPgMQARgMAdAAQAeAAAWAMIgKAaQgUgIgUAAQgVAAAAAOQAAAIAZAGQAZAIALAHQATAMgBAXQAAAshDAAQgkABgZgMg");
	this.shape_5.setTransform(70.8,17.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0052C2").s().p("AgUBrIAAjVIAqAAIAADVg");
	this.shape_6.setTransform(50.6,13.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0052C2").s().p("AgVBrIAAjVIAqAAIAADVg");
	this.shape_7.setTransform(42.4,13.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0052C2").s().p("Ag6A+QgJgMAAgQQAAgWAQgMQAOgLAZgCIAngCIAAgEQAAgNgFgGQgHgGgPAAQgXAAgXAHIgHgaQAdgNAiAAQA6AAAAA0IAABiIgmAAIgCgPIAAAAQgVASgcAAQgZAAgMgPgAgCAKQgUACAAASQAAATAUAAQAOAAAPgNIAAgcg");
	this.shape_8.setTransform(29.9,17.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#0052C2").s().p("AgjAzIAAhNIgVAAIAAgXIAYgHIAKgjIAcgDIAAAoIArAAIAAAcIgrAAIAABCQAAAMAEAFQAFAGALAAQAIAAASgEIAFAcQgTAIgXAAQgyAAAAgsg");
	this.shape_9.setTransform(7.3,15.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#0052C2").s().p("AgVBnIAAjNIArAAIAADNg");
	this.shape_10.setTransform(-3.4,14.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.copy1, new cjs.Rectangle(-10,0,157.6,34), null);


(lib.bull_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.bull();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.bull_mc, new cjs.Rectangle(0,0,178,190), null);


(lib.End_CTA = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{myPlay:1});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.gotoAndStop(0);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(1));

	// basePlate as mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Aq2ifIVtAAIAAE/I1tAAg");
	mask.setTransform(69.5,16);

	// glare
	this.instance = new lib.brandBar_graphic_button_highlight();
	this.instance.parent = this;
	this.instance.setTransform(-11.4,-19.7,1,1.15,0,29.7,0);
	this.instance.alpha = 0.301;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:172,y:-19},29).wait(1));

	// text_CTA_80% (thicken font)
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgkAAQAAgPAHgMQAKgSAUAAQAkAAAAAqIAAAGIg6AAQAAAfAYAAQANAAAPgGIAEAKQgPAIgSAAQgmAAAAgugAAXgFQAAgdgVAAQgVAAgBAdIArAAIAAAAg");
	this.shape.setTransform(108.4,17.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgXAtIAAhXIAOAAIABAQIAAAAQAGgJAIgEQAIgFAKAAIAAAOQgVABgLAPIAAA7g");
	this.shape_1.setTransform(101.4,17);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgeAgQgIgLAAgUQAAgTAJgMQALgPATAAQAUAAAKAPQAIAMAAASQAAAUgJALQgKAPgUAAQgUAAgKgOgAgXABQABAPAEAIQAGAKANAAQAWAAAAghQAAgigWAAQgXAAgBAig");
	this.shape_2.setTransform(93,17.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAvAtIAAg5QAAgKgCgFQgEgFgKAAQgNAAgMAIIABAMIAAA5IgNAAIAAg8QAAgRgPAAQgMAAgOAJIAABEIgOAAIAAhXIAOAAIAAAIIABABQAPgLAPAAQAOAAAGALQAPgLAQAAQARAAAGAKQAEAGAAAOIAAA7g");
	this.shape_3.setTransform(81,17);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAVAtIAAg5QAAgKgCgFQgEgFgJAAQgLAAgPAJIAABEIgPAAIAAhXIAPAAIAAAIIAAAAQAQgKAOAAQAQAAAGAJQAEAHAAANIAAA8g");
	this.shape_4.setTransform(64.2,17);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgXAtIAAhXIAOAAIABAQIAAAAQAFgJAJgEQAIgFAKAAIAAAOQgUABgMAPIAAA7g");
	this.shape_5.setTransform(57.1,17);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgdAlQgGgGAAgKQAAgMAJgHQAIgGAOgBIAZgBIAAgGQAAgLgEgFQgEgFgLAAQgLAAgPAFIgEgJQAQgIARABQAegBAAAeIAAA8IgNAAIAAgKIgBAAQgNALgRAAQgNAAgHgJgAgBAEQgSABAAAPQABAQAPAAQALgBANgKIAAgXg");
	this.shape_6.setTransform(49,17.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgkAAQAAgPAHgMQAKgSAVAAQAjAAAAAqIAAAGIg6AAQAAAfAYAAQANAAAPgGIAEAKQgPAIgSAAQgmAAAAgugAAXgFQAAgdgVAAQgVAAgCAdIAsAAIAAAAg");
	this.shape_7.setTransform(40.3,17.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgnA+IAAh7IAPAAIAABvIBAAAIAAAMg");
	this.shape_8.setTransform(31.5,15.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(30));

	// text_CTA
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgkAAQAAgPAHgMQAKgSAUAAQAkAAAAAqIAAAGIg6AAQAAAfAYAAQANAAAPgGIAEAKQgPAIgSAAQgmAAAAgugAAXgFQAAgdgVAAQgVAAgBAdIArAAIAAAAg");
	this.shape_9.setTransform(108.4,17.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgXAtIAAhXIAOAAIABAQIAAAAQAGgJAIgEQAIgFAKAAIAAAOQgVABgLAPIAAA7g");
	this.shape_10.setTransform(101.4,17);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgeAgQgIgLAAgUQAAgTAJgMQALgPATAAQAUAAAKAPQAIAMAAASQAAAUgJALQgKAPgUAAQgUAAgKgOgAgXABQABAPAEAIQAGAKANAAQAWAAAAghQAAgigWAAQgXAAgBAig");
	this.shape_11.setTransform(93,17.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAvAtIAAg5QAAgKgCgFQgEgFgKAAQgNAAgMAIIABAMIAAA5IgNAAIAAg8QAAgRgPAAQgMAAgOAJIAABEIgOAAIAAhXIAOAAIAAAIIABABQAPgLAPAAQAOAAAGALQAPgLAQAAQARAAAGAKQAEAGAAAOIAAA7g");
	this.shape_12.setTransform(81,17);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAVAtIAAg5QAAgKgCgFQgEgFgJAAQgLAAgPAJIAABEIgPAAIAAhXIAPAAIAAAIIAAAAQAQgKAOAAQAQAAAGAJQAEAHAAANIAAA8g");
	this.shape_13.setTransform(64.2,17);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgXAtIAAhXIAOAAIABAQIAAAAQAFgJAJgEQAIgFAKAAIAAAOQgUABgMAPIAAA7g");
	this.shape_14.setTransform(57.1,17);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgdAlQgGgGAAgKQAAgMAJgHQAIgGAOgBIAZgBIAAgGQAAgLgEgFQgEgFgLAAQgLAAgPAFIgEgJQAQgIARABQAegBAAAeIAAA8IgNAAIAAgKIgBAAQgNALgRAAQgNAAgHgJgAgBAEQgSABAAAPQABAQAPAAQALgBANgKIAAgXg");
	this.shape_15.setTransform(49,17.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgkAAQAAgPAHgMQAKgSAVAAQAjAAAAAqIAAAGIg6AAQAAAfAYAAQANAAAPgGIAEAKQgPAIgSAAQgmAAAAgugAAXgFQAAgdgVAAQgVAAgCAdIAsAAIAAAAg");
	this.shape_16.setTransform(40.3,17.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgnA+IAAh7IAPAAIAABvIBAAAIAAAMg");
	this.shape_17.setTransform(31.5,15.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]}).wait(30));

	// basePlate
	this.instance_1 = new lib.brandBar_graphic_button_basePlate();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.678,0.667);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,139,32);


(lib.brandBar_graphic_CTAbutton = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"myPlay":1});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.gotoAndStop(0);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(1));

	// basePlate as mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AqYiVIUxAAIAAE1I0xAAg");
	mask.setTransform(66.5,16);

	// glare
	this.instance = new lib.brandBar_graphic_button_highlight();
	this.instance.parent = this;
	this.instance.setTransform(-11.4,-19.7,1,1.15,0,29.7,0);
	this.instance.alpha = 0.301;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:167,y:-20},29).wait(1));

	// text_CTA_80% (thicken font)
	this.instance_1 = new lib.brandBar_graphic_text_CTA();
	this.instance_1.parent = this;
	this.instance_1.setTransform(30,9);
	this.instance_1.alpha = 0.801;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(30));

	// text_CTA
	this.instance_2 = new lib.brandBar_graphic_text_CTA();
	this.instance_2.parent = this;
	this.instance_2.setTransform(30,9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(30));

	// basePlate
	this.instance_3 = new lib.brandBar_graphic_button_basePlate();
	this.instance_3.parent = this;
	this.instance_3.setTransform(0,1,0.649,0.646);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,1,133,31);


(lib.end_logo = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// logo
	this.instance = new lib.logo_big();
	this.instance.parent = this;
	this.instance.setTransform(79.1,77.5,1.1,1.1,0,0,0,55.5,49.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.end_logo, new cjs.Rectangle(59.8,46.1,86,76.7), null);


(lib.bull_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.bull_mc();
	this.instance.parent = this;
	this.instance.setTransform(110,117.5,1,1,0,0,0,110,117.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.bull_1, new cjs.Rectangle(0,0,178,190), null);


(lib.CONTENT_brandBar_mc = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Merrill Lynch
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AFzCGIAAg3IAGAAIAAAIQADgJAJAAQAIAAAFAHQAEAGAAAJQAAAIgEAFQgFAIgIAAQgHAAgFgHIAAAUgAF9BXQgDACgBAFIAAAKQAAAFADADQAEAEAEAAQAGAAACgFQADgEAAgHQAAgGgCgEQgDgGgGAAQgEAAgDADgAJBByQgEgGAAgIQAAgKAFgGQAFgGAJAAQAJAAAFAHQAEAGAAAJQAAAJgFAGQgFAGgJAAQgJAAgFgHgAJGBaQgCADAAAHQAAAGADAFQACAFAHAAQAGAAADgGQACgEAAgGQAAgHgDgFQgDgEgFAAQgHgBgDAHgAIeB5QgHAAgCgDQgDgEAAgGIAAgYIgHAAIAAgFIAHAAIAAgKIAHgBIAAALIAJAAIAAAFIgJAAIAAAZIABAFQABACAEAAIAFgBIAAAGgAHnB2QgEgDAAgGQAAgEACgDQACgDADgCQAFgCALAAIAFAAIAAgCQAAgFgCgDQgDgCgFAAQgKAAgBAIIgGgBQABgHAFgCQAFgDAGAAQAKAAADAFQACACABADIAAAIIAAAQIABAIIgGAAIgBgIQgEAJgKAAQgGAAgEgDgAHpBtQAAADADACQADACADABQAGAAAEgFQADgEAAgFIAAgDIgFAAQgRAAAAAJgAGgByQgEgGAAgIQAAgKAEgGQAGgGAJAAQAIAAAFAHQAFAGAAAJQAAAJgFAGQgGAGgJAAQgIAAgFgHgAGlBaQgCADAAAHQAAAGACAFQADAFAGAAQAGAAAEgGQACgEAAgGQAAgHgDgFQgDgEgGAAQgGgBgDAHgAEuByQgEgGAAgIQAAgKAFgGQAFgGAJAAQAJAAAEAHQAFAGAAAJQAAAJgFAGQgFAGgJAAQgJAAgFgHgAEzBaQgCADAAAHQAAAHACAEQADAFAGAAQAHAAADgGQACgEAAgGQAAgHgDgFQgDgEgGAAQgGgBgDAHgAD+BwQgGgIAAgMQAAgMAGgHQAGgJAMAAQAIAAAFAFQAFAFACAIIgHABQgEgNgKAAQgIAAgEAHQgDAHAAAJQAAAIADAFQAEAJAIAAQALAAADgNIAHABQgFASgQAAQgLAAgGgJgAC6B2QgFgDAAgGQAAgEACgDIAGgFQAFgCALAAIAFAAIAAgCQAAgFgCgDQgDgCgFAAQgKAAgCAIIgGgBQABgHAGgCQAFgDAGAAQAJAAAEAFQACACABADIAAAIIAAAQIABAIIgGAAIgBgIQgEAJgKAAQgHAAgDgDgAC8BtQAAADADACQACACAEABQAGAAADgFQAEgEAAgFIAAgDIgFAAQgRAAAAAJgACSByQgEgFAAgJQAAgJAEgGQAFgHAIAAQAHAAAEAEQAEAEABAHIgGAAQAAgEgDgDQgDgCgEAAQgGAAgCAFQgDAEAAAHQAAAGACAEQADAGAGAAQAIAAACgKIAGABQgBAGgEAEQgEAEgHAAQgJAAgEgHgAA4BzQgFgGAAgJQAAgJAFgGQAFgHAJAAQAJAAAFAHQAFAGgBAKIgeAAQAAAGACADQADAGAIAAQAIAAADgIIAGACQgCAFgFADQgFADgGAAQgJAAgFgGgAA+BXQgDAEAAAEIAWAAQAAgFgCgDQgDgEgGAAQgFAAgDAEgAiRByQgEgGAAgIQAAgKAEgGQAGgGAIAAQAJAAAFAHQAFAGAAAJQAAAJgFAGQgGAGgJAAQgIAAgFgHgAiMBaQgCADAAAHQAAAHACAEQADAFAGAAQAGAAADgGQADgEAAgGQAAgHgDgFQgDgEgGAAQgGgBgDAHgAkpB2QgEgDAAgGQAAgEACgDQACgDAEgCQAFgCALAAIAFAAIAAgCQAAgFgCgDQgDgCgFAAQgKAAgCAIIgGgBQABgHAGgCQAFgDAGAAQAJAAAEAFQACACABADIAAAIIAAAQIABAIIgGAAIgBgIQgEAJgKAAQgHAAgEgDgAkmBtQAAADADACQACACAEABQAGAAADgFQAEgEAAgFIAAgDIgFAAQgRAAAAAJgAKFB4IAAgZQAAgGgCgCQgBgDgFAAQgGAAgDAEQgDAEAAAHIAAAVIgHAAIAAgpIAGAAIAAAIIABAAQAEgJAIAAQAIAAAEAGQACAEAAAKIAAAWgAItB4IAAgpIAGAAIAAApgAHKB4IAAgpIAGAAIAAAKQAEgLAIAAIACAAIAAAGIgBAAQgHABgEAGQgCAEAAAFIAAAUgAFYB4IAAgpIAGAAIAAAKQAEgLAIAAIADAAIAAAGIgCAAQgGABgEAGQgCADAAAGIAAAUgAB+B4IAAgpIAGAAIAAApgABhB4IAAgpIAGAAIAAAKIAAAAQAEgLAIAAIADAAIAAAGIgCAAQgHABgDAGQgCADAAAGIAAAUgAAlB4IAAgYIgBgJQgCgDgFAAQgFAAgDAEIgCAFIAAAFIAAAWIgGAAIAAgaQAAgFgCgCQgCgDgFAAQgEAAgCADQgDAEAAAGIAAAXIgGAAIAAgpIAGAAIAAAIIAAAAQACgDADgDQACgDAEAAQAFAAADADQADADABAEQACgEADgDQAEgDAEAAQAHAAAEAGQABADAAAJIAAAYgAgYB4IgGgQIgUAAIgFAQIgGAAIASg3IAIAAIASA3gAgwBjIARAAIgJgagAhmB4IAAgkIgIAAIAAgFIAIAAQgBgHADgEQADgFAHABIAGABIAAAEIgFAAQgFAAgBAEIgBAGIAJAAIAAAFIgJAAIAAAkgAi4B4IgMgXIgJALIAAAMIgHAAIAAg3IAHAAIAAAkIATgWIAHAAIgNAPIAOAagAjmB4IAAgZIgBgIQgCgDgFAAQgFAAgDAEQgDAEAAAHIAAAVIgHAAIAAgpIAGAAIAAAIQAFgJAIAAQAIAAAEAGQACAEAAAKIAAAWgAlbB4IAAg3IAVAAQAIAAAEACQAFAEAAAHQAAAFgCADQgDADgEACQAFACADADQADAEAAAFQAAAHgFAFIgHADIgHAAgAlUByIAOAAQAGAAADgCQADgDAAgEQAAgGgEgDQgDgCgGAAIgNAAgAlUBYIALAAQAHAAADgCQADgCAAgFQAAgFgEgCQgCgCgFAAIgNAAgAnZB4QAFgGAMgWQgGADgHgCQgIgBgCgEQgCgEgCABIgEAFIgIANIgJARIgiAAQAIgIAGgNQAGgPgBgHIgKABQABgDgFgCQgFgCgGAEQABAFgBAJIgBAOQgPAAgNgHQgOgGgDgJQAAgBAAAAQgBAAAAAAQAAAAgBAAQAAAAgBABIgEABQgFAAgDgDIgDANIgDAMQgCANABADIgdAAQAFgNAAgOQABgQgFgKQgEgIgBgLQAAgKADgFQgHgJgBgMQgCgOAKgXQALgbAFgWQgHAEgHABQgBgEABgGQACgGADgDQgHgIAAgMQAAgJAJgIQAIgHAJAAQAKAAAEADQgEACgCADQgCADAAADIABAFQABABAAAAQAAABABAAQAAAAABAAQAAAAABAAIADgBIACgBIAdAAQADADADAAQAEAAACgDQACgDAAgCQAAgDgBgDQgCgEgEgBQAFgEAGAAQAIAAAIAIQAIAIAAANQAAAFgBAEQgBAFgEAEIAFAIIACAIIgOABIAHAMIAGAPQAMAeAUAJQAQAIAOABQAQAEAPgFQAHgBAEgFQAEgGAAgGQAAgGgKgJQgJgIgMgEQgbgFgNgHQgYgLAAgVQABgMALgIQAMgJAQAAIA+gBQgCAKgJAKQgKANgLAAQgKAAgFgDIgIgFQgMgHgHABQgGAAgFADQgGAEAAAIQAAAOAWAHIAUAHQAPADAJAFQAcAMAAAUQAAAMgLAJQgMAIgSABQAJANAFAMQADAIAHAHQAIAKAIABQgIAMgGAOQgGAPAAAKgAnuATQgGAEAAAHQAAARAPAIQAMAIAUAGQAIAEACAGQABAFgEAKIgKASIAOAAQABgHAFgMQAFgMAEgGQgHgFgGgLIgLgUQgDgIgHgHQgKgKgKgBQgIAAgFAGgAp6AwIgBACQAAAFAFASQADAJAAALQABAKgDAJIAHAAQABgDACgPIADgUQAAgIgIgKQgHgKgBABIgCABgAn8BLQAAAKgEAMQgDAJgEAGIAIAAIAMgUIAKgRIAAgCQgMAAgHACgAo3AzIgJAJQgGAJAAAFQAAAEACADQADAEAFACIAKAEIAIABQACgIgBgGQgFABgHAAQgIAAgCgDQADgDAFgBIAHgCQADgBAFgDQAGgFAAgEQAAgEgDgDQgDgCgFAAQgFAAgFADgAnbBQQACAEAEAAQAEAAADgBQADgBABgCQgCgCgHgDIgKgCQAAAEACADgAp+gBQgDACAAAFQAAAGADAHQAGANAcAkQABABAAAAQABABAAAAQABAAAAAAQABAAABAAQADABACgCQAJgJAEgIQAFgLAIgIQAHgGALgHQAIgFAFgJQAGgIAAgNQAAgPgLgUIgPgYQgDACgDADQgEAFAAAEIABADIABAEQAAAAAAAAQAAABgBAAQAAABAAAAQgBABAAAAIgDABIgEgBIgHgCIgJAAIgFACQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAgBgBAAQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBQABAAAAAAQAAgBAAAAQABgBAAAAIADgBIAGABQAFACAFgCQAFgCgCgEIgBgJIABgIQACgEADgDIAPAAQAHAAAFgGQAEgFAAgGQAAgEgDgGIgGgGQACAGgBAFQgBADgDAEQgEADgFAAIgFgBIgFgCIgdAAQgCAFgGAAQgDAAgEgDIgFgFQgCgHADgHQgFABgDAEQgEADAAAGQAAAHAGAFQAFAGAHABQgCANgHAVIgLAeQgDAIAGADQAGADAHAJQAIAJABAKIgIAAQgBgGgGgIQgEgFgFgCIgCAAIgEABgAoGBCIAUgGQgEgFgEgIQgEgJAAgHQAAgHAEgIQAEgGAFgDQgFgBgIgGQgKgGgCgFQAAAGgCAGQgCAHgDAFQgEAFgJAHQgLAIgDAEQAJABAGAIQAFAGgBAJIAUgEQgBADAAAGgAo4hRQgDAEAAAFQAFgBADgDQADgCAAgHQgFABgDADgAnUhkQAAABAAAAQAAABAAAAQABABAAAAQABABAAABIAHACQAGACAFAAQAFABAGgFQAEgEADgEIgfAAQgGAAgBADgAItBIIAAgHIAHAAIAAAHgAB+BIIAAgHIAGAAIAAAHgAEMAnIAAgUIAIABQAQAAAAgLIgBgIIgXhNIAeAAIAKA1IABAAIAMg1IAXAAIgfBcQgEAOgKAFQgIAFgOAAIgJgBgAHBABQgLgMAAgSQAAgUALgNQALgQATAAQAUAAAKAOQAGAKAAAMIgZAAQAAgHgBgEQgDgHgGABQgGgBgDAJQgBAGAAAPQAAAPACAGQACAGAGAAQALAAAAgRIAXADQgCAQgJAHQgJAJgQAAQgSAAgLgOgAjPABQgJgMAAgUQAAgUAKgNQAKgOAUAAQATAAAKAPQAIANAAATIAAAHIgwAAQgBAIADAFQADAIAIAAQAFAAAEgDQAEgEABgFIAUAHQgDAHgGAFQgLALgQAAQgUAAgLgOgAi5g1QgDAEABAIIAVAAQABgSgMAAQgFgBgDAHgAI7ANIAAg/QAAgIgHAAQgEAAgDAFIgCACIAABAIgdAAIAAh+IAdAAIAAAxIABAAQAJgOAQAAQAJAAAFAFQAFAGAAAJIAABHgAGPANIAAg9QAAgHgHgBQgFAAgEAGIAAA/IgdAAIAAhZIAcAAIAAAJIABAAQALgLAOAAQAJAAAGAGQAFAFAAAKIAABGgAC7ANIAAh+IAgAAIAABpIAsAAIAAAVgABfANIAAh+IAdAAIAAB+gAA0ANIAAh+IAdAAIAAB+gAAFANIAAhZIAdAAIAABZgAg+ANIAAhZIAcAAIAAAMIABAAQAEgGAIgEQAHgEAJAAIAAAdQgGgCgGAAQgKAAgGAHIAAA5gAiAANIAAhZIAcAAIAAAMIABAAQAEgGAIgEQAHgEAJAAIAAAdQgHgCgFAAQgKAAgGAHIAAA5gAkEANIAAhdIgWBdIgUAAIgUhgIAAAAIAABgIgZAAIAAh+IAtAAIAOBHIARhHIAsAAIAAB+gAo9gqQgFgCgGAAQgGAAgFACQAAAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAgBAAAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAFgEAHAAQAHAAAFAEQAAABAAAAQABABAAAAQAAABAAAAQAAAAAAABIgBAAIgBAAgApdhNQgCgDAAgFQAFABADADQADADgBAFQgFAAgDgEgAAFhXIAAgaIAdAAIAAAag");
	this.shape.setTransform(77.7,24,1,1,0,0,0,0.6,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// button
	this.myButton_mc = new lib.brandBar_graphic_CTAbutton();
	this.myButton_mc.name = "myButton_mc";
	this.myButton_mc.parent = this;
	this.myButton_mc.setTransform(11,48);

	this.timeline.addTween(cjs.Tween.get(this.myButton_mc).wait(1));

	// bar
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#012169").s().p("Ar/HCIAAuDIX/AAIAAODg");
	this.shape_1.setTransform(77,45,1.002,1);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.CONTENT_brandBar_mc, new cjs.Rectangle(-40.2,0,194.3,98.3), null);


(lib.CONTENT_mc = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_772 = function() {
		this.stop();
		stage.enableMouseOver();
		
		this.endcta_mc.gotoAndPlay('myPlay');
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(772).call(this.frame_772).wait(1));

	// hit_area
	this.instance = new lib.hit_area();
	this.instance.parent = this;
	this.instance.setTransform(150,125,1,1,0,0,0,150,125);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.hit_area(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(773));

	// end_cta
	this.endcta_mc = new lib.End_CTA();
	this.endcta_mc.name = "endcta_mc";
	this.endcta_mc.parent = this;
	this.endcta_mc.setTransform(709.5,377);
	this.endcta_mc.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.endcta_mc).wait(694).to({x:559,y:29},0).to({alpha:1},32,cjs.Ease.sineOut).wait(47));

	// copy7
	this.instance_1 = new lib.copy7();
	this.instance_1.parent = this;
	this.instance_1.setTransform(336.2,75,1,1,0,0,0,109.2,7);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(694).to({_off:false},0).to({alpha:1},32,cjs.Ease.sineOut).wait(47));

	// Copy6
	this.instance_2 = new lib.Copy6();
	this.instance_2.parent = this;
	this.instance_2.setTransform(320.5,38,1,1,0,0,0,117.5,21);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(694).to({_off:false},0).to({alpha:1},32,cjs.Ease.sineOut).wait(47));

	// line
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#21397A").ss(2,2,0,3).p("AgOAAIAdAA");
	this.shape.setTransform(67.6,56);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#21397A").ss(2,2,0,3).p("AgyAAIBlAA");
	this.shape_1.setTransform(67.6,56);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#21397A").ss(2,2,0,3).p("AhUAAICpAA");
	this.shape_2.setTransform(67.6,56);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#21397A").ss(2,2,0,3).p("Ah0AAIDpAA");
	this.shape_3.setTransform(67.7,56);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#21397A").ss(2,2,0,3).p("AiRAAIEjAA");
	this.shape_4.setTransform(67.7,56);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#21397A").ss(2,2,0,3).p("AitAAIFaAA");
	this.shape_5.setTransform(67.7,56);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#21397A").ss(2,2,0,3).p("AjGAAIGNAA");
	this.shape_6.setTransform(67.7,56);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#21397A").ss(2,2,0,3).p("AjdAAIG7AA");
	this.shape_7.setTransform(67.8,56);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#21397A").ss(2,2,0,3).p("AjyAAIHlAA");
	this.shape_8.setTransform(67.8,56);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#21397A").ss(2,2,0,3).p("AkFAAIILAA");
	this.shape_9.setTransform(67.8,56);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#21397A").ss(2,2,0,3).p("AkXAAIIvAA");
	this.shape_10.setTransform(67.8,56);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#21397A").ss(2,2,0,3).p("AknAAIJPAA");
	this.shape_11.setTransform(67.8,56);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#21397A").ss(2,2,0,3).p("Ak1AAIJrAA");
	this.shape_12.setTransform(67.9,56);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#21397A").ss(2,2,0,3).p("AlCAAIKFAA");
	this.shape_13.setTransform(67.9,56);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#21397A").ss(2,2,0,3).p("AlNAAIKbAA");
	this.shape_14.setTransform(67.9,56);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#21397A").ss(2,2,0,3).p("AlXAAIKvAA");
	this.shape_15.setTransform(67.9,56);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#21397A").ss(2,2,0,3).p("AlgAAILBAA");
	this.shape_16.setTransform(67.9,56);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#21397A").ss(2,2,0,3).p("AloAAILRAA");
	this.shape_17.setTransform(67.9,56);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#21397A").ss(2,2,0,3).p("AluAAILdAA");
	this.shape_18.setTransform(67.9,56);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#21397A").ss(2,2,0,3).p("Al0AAILpAA");
	this.shape_19.setTransform(67.9,56);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#21397A").ss(2,2,0,3).p("Al4AAILxAA");
	this.shape_20.setTransform(67.9,56);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#21397A").ss(2,2,0,3).p("Al8AAIL5AA");
	this.shape_21.setTransform(67.9,56);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#21397A").ss(2,2,0,3).p("Al/AAIL/AA");
	this.shape_22.setTransform(67.9,56);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#21397A").ss(2,2,0,3).p("AmCAAIMEAA");
	this.shape_23.setTransform(67.9,56);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#21397A").ss(2,2,0,3).p("AmDAAIMHAA");
	this.shape_24.setTransform(67.9,56);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#21397A").ss(2,2,0,3).p("AmEAAIMKAA");
	this.shape_25.setTransform(67.9,56);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#21397A").ss(2,2,0,3).p("AmFAAIMLAA");
	this.shape_26.setTransform(67.9,56);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#21397A").ss(2,2,0,3).p("AmGAAIMNAA");
	this.shape_27.setTransform(67.9,56);
	this.shape_27._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},678).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_27}]},1).wait(65));
	this.timeline.addTween(cjs.Tween.get(this.shape_27).wait(705).to({_off:false},0).wait(68));

	// endframe_img
	this.instance_3 = new lib.end_logo();
	this.instance_3.parent = this;
	this.instance_3.setTransform(75.5,58.5,1,1,0,0,0,108.5,97.5);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(634).to({_off:false},0).to({alpha:1},22,cjs.Ease.quintInOut).wait(117));

	// blue_bg
	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#012169").s().p("AsAHCIAAuDIYCAAIAAODg");
	this.shape_28.setTransform(651.1,45);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#012169").s().p("AsBHCIAAuDIYDAAIAAODg");
	this.shape_29.setTransform(651,45);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#012169").s().p("AsEHCIAAuDIYJAAIAAODg");
	this.shape_30.setTransform(650.7,45);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#012169").s().p("AsMHCIAAuDIYZAAIAAODg");
	this.shape_31.setTransform(649.9,45);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#012169").s().p("AscHCIAAuDIY5AAIAAODg");
	this.shape_32.setTransform(648.3,45);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#012169").s().p("As2HCIAAuDIZtAAIAAODg");
	this.shape_33.setTransform(645.7,45);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#012169").s().p("AtcHCIAAuDIa5AAIAAODg");
	this.shape_34.setTransform(641.9,45);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#012169").s().p("AuSHCIAAuDIclAAIAAODg");
	this.shape_35.setTransform(636.5,45);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#012169").s().p("AvaHCIAAuDIe1AAIAAODg");
	this.shape_36.setTransform(629.3,45);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#012169").s().p("Aw3HCIAAuDMAhvAAAIAAODg");
	this.shape_37.setTransform(620.1,45);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#012169").s().p("AyqHCIAAuDMAlVAAAIAAODg");
	this.shape_38.setTransform(608.5,45);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#012169").s().p("A03HCIAAuDMApvAAAIAAODg");
	this.shape_39.setTransform(594.5,45);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#012169").s().p("A3fHCIAAuDMAu/AAAIAAODg");
	this.shape_40.setTransform(577.6,45);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#012169").s().p("A6nHCIAAuDMA1PAAAIAAODg");
	this.shape_41.setTransform(557.6,45);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#012169").s().p("A+PHCIAAuDMA8gAAAIAAODg");
	this.shape_42.setTransform(534.4,45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#012169").s().p("EgicAHCIAAuDMBE5AAAIAAODg");
	this.shape_43.setTransform(507.5,45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#012169").s().p("EgmoAHCIAAuDMBNRAAAIAAODg");
	this.shape_44.setTransform(480.7,45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#012169").s().p("EgqRAHCIAAuDMBUjAAAIAAODg");
	this.shape_45.setTransform(457.4,45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#012169").s().p("EgtYAHCIAAuDMBaxAAAIAAODg");
	this.shape_46.setTransform(437.5,45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#012169").s().p("EgwBAHCIAAuDMBgDAAAIAAODg");
	this.shape_47.setTransform(420.6,45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#012169").s().p("EgyOAHCIAAuDMBkdAAAIAAODg");
	this.shape_48.setTransform(406.5,45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#012169").s().p("Eg0BAHCIAAuDMBoDAAAIAAODg");
	this.shape_49.setTransform(395,45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#012169").s().p("Eg1dAHCIAAuDMBq7AAAIAAODg");
	this.shape_50.setTransform(385.8,45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#012169").s().p("Eg2lAHCIAAuDMBtLAAAIAAODg");
	this.shape_51.setTransform(378.6,45);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#012169").s().p("Eg3bAHCIAAuDMBu3AAAIAAODg");
	this.shape_52.setTransform(373.2,45);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#012169").s().p("Eg4CAHCIAAuDMBwFAAAIAAODg");
	this.shape_53.setTransform(369.3,45);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#012169").s().p("Eg4cAHCIAAuDMBw5AAAIAAODg");
	this.shape_54.setTransform(366.7,45);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#012169").s().p("Eg4rAHCIAAuDMBxYAAAIAAODg");
	this.shape_55.setTransform(365.2,45);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#012169").s().p("Eg4zAHCIAAuDMBxoAAAIAAODg");
	this.shape_56.setTransform(364.4,45);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#012169").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_57.setTransform(364.1,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_28}]},626).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57,p:{x:364.1}}]},1).to({state:[{t:this.shape_57,p:{x:364}}]},1).wait(117));

	// Brand Bar
	this.CONTENT_brandBar_mc = new lib.CONTENT_brandBar_mc();
	this.CONTENT_brandBar_mc.name = "CONTENT_brandBar_mc";
	this.CONTENT_brandBar_mc.parent = this;
	this.CONTENT_brandBar_mc.setTransform(724,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.CONTENT_brandBar_mc).to({_off:true},656).wait(117));

	// person_mc
	this.instance_4 = new lib.person_mc();
	this.instance_4.parent = this;
	this.instance_4.setTransform(215,125,1,1,0,0,0,211,125);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(206).to({_off:false},0).to({x:211,alpha:1},57,cjs.Ease.quadInOut).to({_off:true},393).wait(117));

	// Copy5
	this.instance_5 = new lib.copy5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(101.3,78,1,1,0,0,0,66.3,34);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(466).to({_off:false},0).to({alpha:1},33,cjs.Ease.cubicInOut).to({_off:true},157).wait(117));

	// Copy4
	this.instance_6 = new lib.copy4();
	this.instance_6.parent = this;
	this.instance_6.setTransform(74.9,45,1,1,0,0,0,57.9,23);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(269).to({_off:false},0).to({alpha:1},39,cjs.Ease.cubicInOut).wait(121).to({alpha:0},13,cjs.Ease.sineInOut).to({_off:true},1).wait(330));

	// Copy3
	this.instance_7 = new lib.copy3();
	this.instance_7.parent = this;
	this.instance_7.setTransform(92.6,34,1,1,0,0,0,38.6,12);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(224).to({_off:false},0).to({alpha:1},39,cjs.Ease.quadInOut).wait(510));

	// Copy2
	this.instance_8 = new lib.copy2();
	this.instance_8.parent = this;
	this.instance_8.setTransform(284.5,41.5,1,1,0,0,0,55.5,14.5);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(73).to({_off:false},0).to({alpha:1},40,cjs.Ease.cubicOut).wait(77).to({alpha:0},16,cjs.Ease.cubicInOut).to({_off:true},1).wait(566));

	// Copy1
	this.instance_9 = new lib.copy1();
	this.instance_9.parent = this;
	this.instance_9.setTransform(143,41.5,1,1,0,0,0,66,14.5);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(20).to({_off:false},0).to({alpha:1},40,cjs.Ease.quadInOut).wait(130).to({alpha:0},16,cjs.Ease.cubicInOut).to({_off:true},1).wait(566));

	// Bull
	this.instance_10 = new lib.bull_1();
	this.instance_10.parent = this;
	this.instance_10.setTransform(495,115.5,1,1,0,0,0,110,117.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(9).to({x:440},640).wait(124));

	// BG
	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_58.setTransform(364,45,2.427,0.36);

	this.timeline.addTween(cjs.Tween.get(this.shape_58).wait(773));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-2,848.5,429.3);


// stage content:
(lib._728x90_OMNI = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		window.root = this;
		
		document.mouseOver = function () {
			exportRoot.content_mc.CONTENT_brandBar_mc.myButton_mc.gotoAndPlay("myPlay");
			exportRoot.content_mc.endcta_mc.gotoAndPlay("myPlay");
		}
		
		this.mouseOut = function () {
			//
		}
		
		//this.content_mc.myButton_mc.cursor = "pointer";
		this.cursor = "pointer";
		//stage.enableMouseOver();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("Eg43AHCIAAuDMBxvAAAIAAODgEg4tAG4MBxbAAAIAAtvMhxbAAAg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// CONTENT_mc
	this.content_mc = new lib.CONTENT_mc();
	this.content_mc.name = "content_mc";
	this.content_mc.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.content_mc).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(364,43,848.5,429.3);
// library properties:
lib.properties = {
	id: '043D0ED927D646D2965332C46EDA8A4E',
	width: 728,
	height: 90,
	fps: 60,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"728x90_OMNI_atlas_.png", id:"728x90_OMNI_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['043D0ED927D646D2965332C46EDA8A4E'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;