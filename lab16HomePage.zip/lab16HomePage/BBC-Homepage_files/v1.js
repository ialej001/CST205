/* Remove comments, minify, gzip, and set appropriate Cache-Control before uploading
 * to CDN */
(function(){
    try {
        var tag = document.getElementById("tl-dco") || window.parent.document.getElementById("tl-dco");
        if (tag) {
            var ct = tag.getAttribute("data-clicktracker");
            if (ct) {
                ct = decodeURIComponent(ct);
                window.parent.postMessage("get_unit_2({'pixel':'"+ct+"','tag_code':0,'auction_id':0,'user_id':0,'campaign_code':'0'});", "*");
            } else {
                throw "no clicktracker";
            }
        } else {
            throw "tl-dco out of scope";
        }
    }
    catch (e) {
        var p = document.createElement('IMG');
        var ref = encodeURIComponent(document.URL);
        p.src = '//eb2.3lift.com/sce?block=dco_v1_js' + '&ref=' + ref + '&e=' + encodeURIComponent(e);
    }
})();
