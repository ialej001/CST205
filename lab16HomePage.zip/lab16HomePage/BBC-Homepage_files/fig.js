typeof orb.orb_fig === 'function' && orb.orb_fig({
'uk':0,
'ck':0,
'ad':1,
'ap':4,
'tb':0,
'mb':0,
'eu':0});
